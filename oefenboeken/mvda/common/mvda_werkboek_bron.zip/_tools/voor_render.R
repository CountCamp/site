# Draait vlak vóór elke render: `pre-render` in _quarto.yml.
#
# In jouw uitgepakte kopie doet deze stap niets; je hoeft er niets mee.
#
# Op de computer waar dit oefenboek gemaakt wordt, bouwt hij de ZIP die je op
# de voorpagina kunt downloaden. Dat gebeurt bij elke render opnieuw, zodat de
# download nooit achterloopt op de website.
#
# Waarom een R-script: Quarto start een .R-script met Rscript, en R heb je voor
# dit oefenboek toch al. Een shellscript zou op Windows niet draaien.
#
# Hoe deze stap weet in welke map hij staat. Drie gevallen:
#
#   1. `_common/R/gt_apa_uit_zip.R` bestaat: dit is een uitgepakte ZIP, want dat
#      bestand zit alleen in de ZIP (zie `_common/R/kaapa.R`). Niets te doen.
#   2. `_tools/maak_bron_zip.sh` bestaat: dit is de bronmap. Bouw de ZIP;
#      mislukt dat, dan stopt de render.
#   3. Geen van beide. Dan klopt er iets niet, en stopt de render meteen, met
#      een melding die zegt wat er mist. In een uitgepakte ZIP zou anders straks
#      geen enkele tabel lukken, en dat geeft halverwege een hoofdstuk een veel
#      vagere fout. In de bronmap zou de download ongemerkt verouderen.
#
# (Staan ze er allebei, dan wint de bronmap: het bouwscript gaat nooit mee in
# de ZIP.)

bouwscript <- file.path("_tools", "maak_bron_zip.sh")
zipkopie   <- file.path("_common", "R", "gt_apa_uit_zip.R")

if (file.exists(bouwscript)) {
  status <- system2("bash", bouwscript)
  if (status != 0) {
    message("voor_render: de download-ZIP is niet gebouwd (afloopcode ", status,
            "); de render stopt.")
    quit(save = "no", status = 1)
  }
} else if (file.exists(zipkopie)) {
  cat("voor_render: uitgepakte kopie van het oefenboek, er valt niets te doen.\n")
} else {
  message("voor_render: in deze map mist de tabelhelper (", zipkopie, "), en",
          " zonder die helper lukt geen enkele tabel.\n",
          "Pak de ZIP van de voorpagina opnieuw uit, in een lege map. Helpt dat",
          " niet, dan ligt het niet aan jou: mail dan naar vragen@countcamp.org.\n",
          "(Is dit de bronmap van het oefenboek, dan mist ", bouwscript, ".)")
  quit(save = "no", status = 1)
}
