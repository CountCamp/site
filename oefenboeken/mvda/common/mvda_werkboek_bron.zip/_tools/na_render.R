# Draait ná elke render: `post-render` in _quarto.yml.
#
# Wat hij doet: losse Griekse letters in de wiskunde rechtop zetten, zoals APA
# dat wil, met het Python-script `_grieks_rechtop.py`. Waarom dat nodig is,
# staat bovenin dat script.
#
# Python hoef je hiervoor niet te installeren. Heb je het niet, of lukt het
# script niet, dan zegt deze stap dat en is de render gewoon klaar. Je
# bladzijden zijn er dan allemaal; alleen staan losse Griekse letters (zoals
# alfa, chi en eta) schuin in plaats van rechtop.
#
# Op de computer waar dit oefenboek gemaakt wordt, is deze stap níét
# vrijblijvend: daar wordt de website gebouwd, dus daar stopt de render als hij
# niet lukt. Die computer herkent hij aan `_tools/maak_bron_zip.sh`, dat
# alleen daar bestaat (zie ook `_tools/voor_render.R`).
#
# Python zoeken gaat zoals Quarto het zelf doet: eerst wat er in QUARTO_PYTHON
# staat, dan op Windows `py` en `python`, en elders `python3`.

streng <- file.exists(file.path("_tools", "maak_bron_zip.sh"))
script <- "_grieks_rechtop.py"

kandidaten <- Sys.getenv("QUARTO_PYTHON")
kandidaten <- c(kandidaten[nzchar(kandidaten)],
                if (.Platform$OS.type == "windows") c("py", "python") else "python3")

# Een kandidaat telt alleen als hij écht Python 3 is. Op Windows kan `python`
# een snelkoppeling naar de Microsoft Store zijn die alleen een melding geeft;
# die valt hier af omdat hij geen "Python 3" terugzegt.
is_python3 <- function(py) {
  uit <- suppressWarnings(tryCatch(
    system2(py, "--version", stdout = TRUE, stderr = TRUE),
    error = function(e) character()))
  is.null(attr(uit, "status")) && any(grepl("^Python 3", uit))
}
gevonden <- Filter(is_python3, kandidaten)

if (length(gevonden) == 0) {
  melding <- paste0("na_render: geen Python gevonden (gezocht: ",
                    paste(kandidaten, collapse = ", "), ").")
  if (streng) {
    message(melding, " De website kan zo niet af; de render stopt.")
    quit(save = "no", status = 1)
  }
  cat(melding, "Geen probleem: de bladzijden zijn klaar, alleen staan losse",
      "Griekse letters schuin in plaats van rechtop.\n")
  quit(save = "no", status = 0)
}

# De uitvoer van het script vangen we op in plaats van hem meteen door te
# geven. Gaat het mis, dan zie je zo eerst wat er aan de hand is, en pas daarna
# wat Python zelf meldde -- en niet andersom, met een rood blok bovenaan.
uit <- suppressWarnings(system2(gevonden[[1]], script, stdout = TRUE, stderr = TRUE))
status <- attr(uit, "status")
if (is.null(status)) status <- 0

if (status == 0) {
  cat(uit, sep = "\n")
} else if (streng) {
  cat(uit, sep = "\n")
  message("na_render: ", script, " gaf afloopcode ", status, ". De render stopt.")
  quit(save = "no", status = 1)
} else {
  cat("na_render: het rechtop zetten van de Griekse letters lukte niet. Geen",
      "probleem: de bladzijden zijn klaar, alleen staan losse Griekse letters",
      "mogelijk schuin in plaats van rechtop.\n")
  cat("Wat Python zelf meldde (je hoeft er niets mee):\n")
  cat(paste0("    ", uit), sep = "\n")
}
