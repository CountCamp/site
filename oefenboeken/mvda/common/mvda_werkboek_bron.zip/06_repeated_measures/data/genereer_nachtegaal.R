# Genereer nachtegaal_zang voor het gemengde design in thema 6 (6.4).
#
# Dier-context: als de kameleon zijn schrift dichtklapt, begint de nachtegaal.
# Hij zingt de hele nacht, maar hoeveel hij zingt hangt af van waar hij zit.
# In het bos is het stil, en daar zingt hij van schemering tot ochtendgloren.
# Langs de snelweg overstemt het verkeer hem bij schemering en bij
# ochtendgloren; hij bewaart zijn lied voor het stille midden van de nacht. Het
# stadspark zit daartussenin. (Vogels die hun zang naar de stille uren
# verschuiven bestaan echt; deze getallen zijn verzonnen.)
#
# Design: drie-bij-drie gemengd. Tussen: plaats (bos, stadspark, snelweg),
# verschillende nachtegalen per plaats, ongelijke groepen. Binnen: moment
# (schemering, middernacht, ochtendgloren), elke nachtegaal op alle drie.
# Gemeten: zangtijd, het percentage van een kwartier waarin hij zingt (0-100).
#
# Wide format, zoals kameleon_momenten: één rij per nachtegaal. Het lange
# format maakt het oefenboek zelf, met pivot_longer().
#
# Waarom drie groepen en niet twee: bij drie groepen heeft de interactie
# plaats x moment twee dimensies (min(3 - 1, 3 - 1) = 2), en dan geven Pillai,
# Wilks, Hotelling-Lawley en Roy voor die interactie verschillende F-getallen.
# Het oefenboek laat dan alle vier rapporteren; bij de kameleon (geen
# tussen-groepen-factor) kon je dat niet zien.
#
# Waarom ongelijke groepen: dan doet Type III ertoe, zoals de tekst zegt.
# De kleinste groep heeft er 22, boven de vuistregel van 20.
#
# Doelen voor de kalibratie (populatie, niet de steekproef):
#   - bos:       70, 74, 72  (zingt de hele nacht, moment doet weinig)
#   - stadspark: 52, 68, 58
#   - snelweg:   32, 64, 42  (diep dal bij schemering en ochtendgloren)
#   - hoofdeffect plaats, hoofdeffect moment en de interactie alle drie
#     significant; de lijnen in de interaction.plot zijn niet parallel
#   - binnen het bos is het effect van moment klein, langs de snelweg groot
#   - within-subject correlaties rond .5
#
# Reproduceerbaar via set.seed(20261011). Draai vanuit 06_repeated_measures/.

set.seed(20261011)

n_per <- c(bos = 26, stadspark = 24, snelweg = 22)
mu <- rbind(
  bos       = c(schemering = 70, middernacht = 74, ochtendgloren = 72),
  stadspark = c(schemering = 52, middernacht = 68, ochtendgloren = 58),
  snelweg   = c(schemering = 32, middernacht = 64, ochtendgloren = 42)
)

sd_intercept <- 9   # tussen-nachtegaal SD: de ene zingt meer dan de andere
sd_residu    <- 9   # binnen-nachtegaal SD per moment

plaats <- factor(rep(names(n_per), times = n_per), levels = names(n_per))
N <- length(plaats)
intercepts <- rnorm(N, mean = 0, sd = sd_intercept)

Y <- mu[as.character(plaats), ] + intercepts +
  matrix(rnorm(N * 3, mean = 0, sd = sd_residu), nrow = N)

# Een percentage ligt tussen 0 en 100; afronden op één decimaal.
Y <- round(pmin(pmax(Y, 0), 100), 1)

nachtegaal_zang <- data.frame(
  id            = factor(sprintf("n%02d", seq_len(N))),
  plaats        = plaats,
  schemering    = Y[, "schemering"],
  middernacht   = Y[, "middernacht"],
  ochtendgloren = Y[, "ochtendgloren"]
)
rownames(nachtegaal_zang) <- NULL

# Snelle controles.
cat("--- structuur ---\n"); str(nachtegaal_zang)
cat("--- n per plaats ---\n"); print(table(nachtegaal_zang$plaats))
cat("--- gemiddelden per plaats per moment ---\n")
print(aggregate(cbind(schemering, middernacht, ochtendgloren) ~ plaats,
                data = nachtegaal_zang, FUN = function(x) round(mean(x), 2)))
cat("--- correlaties tussen de momenten ---\n")
print(round(cor(nachtegaal_zang[, c("schemering", "middernacht", "ochtendgloren")]), 2))
cat("--- buiten 0-100 afgekapt ---\n")
print(sum(Y == 0 | Y == 100))

suppressPackageStartupMessages(library(car))
options(contrasts = c("contr.sum", "contr.poly"))
lm_n <- lm(cbind(schemering, middernacht, ochtendgloren) ~ plaats, data = nachtegaal_zang)
idata <- data.frame(moment = factor(c("schemering", "middernacht", "ochtendgloren"),
                                    levels = c("schemering", "middernacht", "ochtendgloren")))
res_n <- Anova(lm_n, idata = idata, idesign = ~moment, type = 3)
print(summary(res_n, multivariate = TRUE))

save(nachtegaal_zang, file = "data/nachtegaal_zang.RData")
