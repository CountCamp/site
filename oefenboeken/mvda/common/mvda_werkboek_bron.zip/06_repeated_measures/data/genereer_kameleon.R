# Genereer kameleon_momenten dataset voor het RMA-thema (6.1, 6.2).
#
# Dier-context: een kameleon laat zich slecht beschrijven door één meting.
# Op vier momenten van de dag is hij telkens een ander stuk van zichzelf —
# rustig in de ochtend, identiteits-loos in de middag, herstellend in de avond,
# volledig zichzelf in de nacht. We meten "mate_van_zichzelf" (0-100) bij
# 90 verschillende kameleons, elk op vier momenten (within-subjects).
#
# Wide-format data; long-format wordt in het werkboek waar nodig gemaakt.
#
# Doelen voor de kalibratie:
#   - ochtend:  M ~ 60   (redelijk zichzelf)
#   - middag:   M ~ 35   (identiteits-crisis, laagste)
#   - avond:    M ~ 50   (herstel)
#   - nacht:    M ~ 75   (volledig zichzelf, hoogste)
#   - Within-subject correlaties tussen momenten gemiddeld ~ .50
#   - Multivariate hoofdeffect significant: Pillai V ~ .60, F ~ 35, p < .001
#   - Polynomiale contrasten over momenten:
#       lineair (stijging over de dag) significant
#       kwadratisch (U-vormig met dip in middag) significant
#       kubisch eveneens substantieel (door de op-neer-op-neer-vorm)
#
# Reproduceerbaar via set.seed(20260509).

set.seed(20260509)

n <- 90  # 90 verschillende kameleons
k <- 4   # 4 momenten van de dag

# Cel-gemiddelden per moment.
mu_moments <- c(ochtend = 60, middag = 35, avond = 50, nacht = 75)

# Tussen-persoon-variabiliteit (random intercept per kameleon) — geeft
# de within-subject-correlatie. We willen rho ~ 0.50, dus var_intercept en
# var_residu in dezelfde grootte-orde.
sd_intercept <- 10  # tussen-persoon SD
sd_residu    <- 10  # binnen-persoon SD per moment

# Trekking: eerst random intercept per kameleon, dan op elk moment ruis bovenop.
intercepts <- rnorm(n, mean = 0, sd = sd_intercept)

Y <- matrix(NA_real_, nrow = n, ncol = k)
colnames(Y) <- names(mu_moments)
for (j in seq_len(k)) {
  Y[, j] <- mu_moments[j] + intercepts + rnorm(n, mean = 0, sd = sd_residu)
}

# Clip op [0, 100] en rond af op 1 decimaal.
clip01 <- function(x) pmin(pmax(x, 0), 100)
Y <- apply(Y, 2, clip01)
Y <- round(Y, 1)

kameleon_momenten <- data.frame(
  id      = factor(sprintf("k%02d", seq_len(n))),
  ochtend = Y[, "ochtend"],
  middag  = Y[, "middag"],
  avond   = Y[, "avond"],
  nacht   = Y[, "nacht"]
)

# Snelle controles
cat("--- structuur ---\n"); str(kameleon_momenten)
cat("--- N ---\n"); print(nrow(kameleon_momenten))

cat("--- means per moment ---\n")
print(round(colMeans(kameleon_momenten[, -1]), 2))

cat("--- SDs per moment ---\n")
print(round(apply(kameleon_momenten[, -1], 2, sd), 2))

cat("--- correlatiematrix tussen momenten ---\n")
print(round(cor(kameleon_momenten[, -1]), 2))

# RMA fitten — multivariate route via car::Anova met idata + idesign.
suppressPackageStartupMessages(library(car))

Y_mat <- as.matrix(kameleon_momenten[, c("ochtend", "middag", "avond", "nacht")])
lm_kam <- lm(Y_mat ~ 1)

idata <- data.frame(moment = factor(c("ochtend", "middag", "avond", "nacht"),
                                    levels = c("ochtend", "middag", "avond", "nacht")))
res_kam <- Anova(lm_kam, idata = idata, idesign = ~moment, type = 3)
cat("--- RMA multivariate output ---\n")
print(summary(res_kam, multivariate = TRUE, univariate = FALSE))

# Polynomiale contrasten over moment.
contrasts(idata$moment) <- contr.poly(4)
res_kam_poly <- Anova(lm_kam, idata = idata, idesign = ~moment, type = 3)
cat("--- RMA met polynomiale contrasten ---\n")
print(summary(res_kam_poly, multivariate = TRUE, univariate = FALSE))

# Per-trend univariate test via direct verschil-scores.
ochtend <- kameleon_momenten$ochtend
middag  <- kameleon_momenten$middag
avond   <- kameleon_momenten$avond
nacht   <- kameleon_momenten$nacht

# Lineair contrast (-3, -1, 1, 3) / sqrt(20)
c_lin  <- c(-3, -1, 1, 3) / sqrt(20)
c_kw   <- c( 1,-1,-1, 1) / 2
c_kub  <- c(-1, 3,-3, 1) / sqrt(20)

score_lin  <- c_lin[1]*ochtend + c_lin[2]*middag + c_lin[3]*avond + c_lin[4]*nacht
score_kw   <- c_kw[1] *ochtend + c_kw[2] *middag + c_kw[3] *avond + c_kw[4] *nacht
score_kub  <- c_kub[1]*ochtend + c_kub[2]*middag + c_kub[3]*avond + c_kub[4]*nacht

cat("--- t-toets lineaire trend ---\n")
print(t.test(score_lin))
cat("--- t-toets kwadratische trend ---\n")
print(t.test(score_kw))
cat("--- t-toets kubische trend ---\n")
print(t.test(score_kub))

save(kameleon_momenten, file = "data/kameleon_momenten.RData")
