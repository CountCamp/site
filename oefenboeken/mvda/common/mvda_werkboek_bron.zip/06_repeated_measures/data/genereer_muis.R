# Genereer muis_voorzichtigheid mini-dataset voor E5.
#
# Dier-context: een muis observeert haar eigen voorzichtigheid op drie
# momenten rond een gebeurtenis. In rust laag, bij een nieuwe geur (alarm)
# fors omhoog, en na herstel weer omlaag — maar niet helemaal terug naar
# rust ("psychologisch litteken"-effect).
#
# 70 verschillende muizen, elk gemeten op drie momenten (within-subjects).
#
# Doelen:
#   - rust:        M ~ 30
#   - nieuwe_geur: M ~ 65
#   - na_herstel:  M ~ 42
#   - Pillai V > .5, p < .001
#   - Lineair contrast NIET overheersend (geen monotone trend)
#   - Kwadratisch contrast wel substantieel
#
# Reproduceerbaar via set.seed(20260510).

set.seed(20260510)

n <- 70

mu_moments <- c(rust = 30, nieuwe_geur = 65, na_herstel = 42)

sd_intercept <- 8
sd_residu    <- 9

intercepts <- rnorm(n, mean = 0, sd = sd_intercept)

Y <- matrix(NA_real_, nrow = n, ncol = 3)
colnames(Y) <- names(mu_moments)
for (j in seq_along(mu_moments)) {
  Y[, j] <- mu_moments[j] + intercepts + rnorm(n, mean = 0, sd = sd_residu)
}

clip01 <- function(x) pmin(pmax(x, 0), 100)
Y <- apply(Y, 2, clip01)
Y <- round(Y, 1)

muis_voorzichtigheid <- data.frame(
  id          = factor(sprintf("m%02d", seq_len(n))),
  rust        = Y[, "rust"],
  nieuwe_geur = Y[, "nieuwe_geur"],
  na_herstel  = Y[, "na_herstel"]
)

cat("--- structuur ---\n"); str(muis_voorzichtigheid)
cat("--- means per moment ---\n")
print(round(colMeans(muis_voorzichtigheid[, -1]), 2))
cat("--- SDs per moment ---\n")
print(round(apply(muis_voorzichtigheid[, -1], 2, sd), 2))
cat("--- correlaties tussen momenten ---\n")
print(round(cor(muis_voorzichtigheid[, -1]), 2))

# RMA test
suppressPackageStartupMessages(library(car))
Y_mat <- as.matrix(muis_voorzichtigheid[, c("rust", "nieuwe_geur", "na_herstel")])
lm_m <- lm(Y_mat ~ 1)
idata <- data.frame(moment = factor(c("rust", "nieuwe_geur", "na_herstel"),
                                    levels = c("rust", "nieuwe_geur", "na_herstel")))
res_m <- Anova(lm_m, idata = idata, idesign = ~moment, type = 3)
cat("--- RMA muis ---\n")
print(summary(res_m, multivariate = TRUE, univariate = FALSE))

# Polynomiale contrasten
contrasts(idata$moment) <- contr.poly(3)
res_m_poly <- Anova(lm_m, idata = idata, idesign = ~moment, type = 3)
cat("--- met poly contrasten ---\n")
print(summary(res_m_poly, multivariate = TRUE, univariate = FALSE))

save(muis_voorzichtigheid, file = "data/muis_voorzichtigheid.RData")
