# Genereer pissebed_keuzes mini-dataset voor E5.
#
# Dier-context: een pissebed staat onder een blad. Hoeveel licht ze ervaart
# (X) wekt een stress_signaal op (M, mediator), wat de verstoptijd onder de
# steen verlengt (Y). Klein maar duidelijk partieel-mediatie-patroon.
#
# Effect-grootte iets kleiner dan slak — partiële mediation duidelijk.
# Reproduceerbaar via set.seed(20260512).

set.seed(20260512)

n <- 70

# X: licht_blootstelling — continu (lux-achtige schaal 0-100).
licht_blootstelling <- rnorm(n, mean = 50, sd = 15)

# M: stress_signaal — continu (0-100).
# a-pad: positief, gemiddeld.
stress_signaal <- 20 + 0.45 * licht_blootstelling + rnorm(n, 0, 12)

# Y: verstoptijd — continu (seconden, schaal 0-100 voor consistentie).
# b-pad: positief gemiddeld; c'-pad: klein-positief. Partiële mediation.
verstoptijd <- 10 + 0.20 * licht_blootstelling + 0.40 * stress_signaal +
  rnorm(n, 0, 11)

clip01 <- function(x) pmin(pmax(x, 0), 100)
licht_blootstelling <- round(clip01(licht_blootstelling), 2)
stress_signaal      <- round(clip01(stress_signaal),      2)
verstoptijd         <- round(clip01(verstoptijd),         2)

pissebed_keuzes <- data.frame(
  pissebed_id          = factor(sprintf("p%02d", seq_len(n))),
  licht_blootstelling  = licht_blootstelling,
  stress_signaal       = stress_signaal,
  verstoptijd          = verstoptijd
)

cat("--- structuur pissebed_keuzes ---\n"); str(pissebed_keuzes)
cat("--- means + SD's ---\n")
print(round(sapply(pissebed_keuzes[, -1], mean), 2))
print(round(sapply(pissebed_keuzes[, -1], sd),   2))
cat("--- correlaties ---\n")
print(round(cor(pissebed_keuzes[, -1]), 3))

fit_total <- lm(verstoptijd ~ licht_blootstelling, data = pissebed_keuzes)
fit_a     <- lm(stress_signaal ~ licht_blootstelling, data = pissebed_keuzes)
fit_bc    <- lm(verstoptijd ~ licht_blootstelling + stress_signaal,
                data = pissebed_keuzes)

cat("\n--- c (totaal) ---\n")
print(summary(fit_total)$coefficients)
cat("\n--- a (M ~ X) ---\n")
print(summary(fit_a)$coefficients)
cat("\n--- b + c' (Y ~ X + M) ---\n")
print(summary(fit_bc)$coefficients)

a_hat   <- coef(fit_a)["licht_blootstelling"]
b_hat   <- coef(fit_bc)["stress_signaal"]
c_prime <- coef(fit_bc)["licht_blootstelling"]
c_total <- coef(fit_total)["licht_blootstelling"]
ab_hat  <- a_hat * b_hat

cat(sprintf("\na = %.3f, b = %.3f, a*b = %.3f, c' = %.3f, c = %.3f\n",
            a_hat, b_hat, ab_hat, c_prime, c_total))

s_a <- summary(fit_a)$coefficients["licht_blootstelling", "Std. Error"]
s_b <- summary(fit_bc)$coefficients["stress_signaal", "Std. Error"]
z_sobel <- (a_hat * b_hat) / sqrt(a_hat^2 * s_b^2 + b_hat^2 * s_a^2)
p_sobel <- 2 * (1 - pnorm(abs(z_sobel)))
cat(sprintf("Sobel z = %.3f, p = %.5f\n", z_sobel, p_sobel))

save(pissebed_keuzes, file = "data/pissebed_keuzes.RData")
