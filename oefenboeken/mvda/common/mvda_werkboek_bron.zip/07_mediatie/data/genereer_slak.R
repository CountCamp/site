# Genereer slak_ontmoetingen dataset voor het mediatie-thema (7.0, 7.1, 7.2).
#
# Dier-context: een slak ervaart "eerdere afwijzing" als sociale geschiedenis
# (hoe vaak in eerdere ontmoetingen weggetrokken). Die geschiedenis voedt
# een innerlijke sociale_voorzichtigheid (slak-mediator), wat zich vertaalt
# in observeerbare ontmoetingstraagheid (eindgedrag bij nieuwe slak).
#
# Pad-coefficiënten zo gekalibreerd dat:
#   - a-pad (X -> M): positief en sig.
#   - b-pad (M -> Y, controlerend voor X): positief en sig.
#   - c'-pad (X -> Y, controlerend voor M): klein-positief, marginaal.
#   - c (totaal): positief en sig (~ a*b + c').
#   - Sobel-toets: significant.
#   - Visuele decompositie: bijna-volledige mediation.
#
# Daarnaast: een derde set variabelen voor de SUPPRESSIE-illustratie van
# 7.A. Een slak met bouwvaardigheid (X) ontwikkelt door perfectionisme
# (M) een traagheid in actie_snelheid (Y) die haar bouwvaardigheid
# masker — klassiek inconsistente mediation: a > 0, b < 0, |c| < |c'|.
# Beide sets worden bewaard in dezelfde RData-file (twee objecten).
#
# Reproduceerbaar via set.seed(20260511).

set.seed(20260511)

n <- 90

# -------- Hoofd-mediation: afwijzing -> voorzichtigheid -> traagheid -----

# X: eerdere_afwijzing — sociale geschiedenis. Continu schaal 0-100.
# Trekken we als rnorm met M = 50, SD = 15.
eerdere_afwijzing <- rnorm(n, mean = 50, sd = 15)

# M: sociale_voorzichtigheid — innerlijke buffer. Continu schaal 0-100.
# a-pad: stevig positief. M = 25 + 0.55*X + ruis.
sociale_voorzichtigheid <- 25 + 0.55 * eerdere_afwijzing + rnorm(n, 0, 10)

# Y: ontmoetingstraagheid — observeerbaar eindgedrag. Continu 0-100.
# b-pad: stevig positief op M, c'-pad: klein-positief op X.
# Y = 5 + 0.10*X + 0.55*M + ruis.
ontmoetingstraagheid <- 5 + 0.10 * eerdere_afwijzing + 0.55 * sociale_voorzichtigheid + rnorm(n, 0, 10)

# Clip op [0, 100] en rond af.
clip01 <- function(x) pmin(pmax(x, 0), 100)
eerdere_afwijzing       <- round(clip01(eerdere_afwijzing), 2)
sociale_voorzichtigheid <- round(clip01(sociale_voorzichtigheid), 2)
ontmoetingstraagheid    <- round(clip01(ontmoetingstraagheid), 2)

slak_ontmoetingen <- data.frame(
  slak_id                 = factor(sprintf("s%02d", seq_len(n))),
  eerdere_afwijzing       = eerdere_afwijzing,
  sociale_voorzichtigheid = sociale_voorzichtigheid,
  ontmoetingstraagheid    = ontmoetingstraagheid
)

cat("--- structuur slak_ontmoetingen ---\n"); str(slak_ontmoetingen)
cat("--- means + SD's ---\n")
print(round(sapply(slak_ontmoetingen[, -1], mean), 2))
print(round(sapply(slak_ontmoetingen[, -1], sd),   2))
cat("--- correlaties ---\n")
print(round(cor(slak_ontmoetingen[, -1]), 3))

# Drie regressies — Baron-Kenny stappen.
fit_total <- lm(ontmoetingstraagheid ~ eerdere_afwijzing,
                data = slak_ontmoetingen)
fit_a     <- lm(sociale_voorzichtigheid ~ eerdere_afwijzing,
                data = slak_ontmoetingen)
fit_bc    <- lm(ontmoetingstraagheid ~ eerdere_afwijzing + sociale_voorzichtigheid,
                data = slak_ontmoetingen)

cat("\n--- TOTAAL-EFFECT c (Y ~ X) ---\n")
print(summary(fit_total)$coefficients)
cat("\n--- a-PAD (M ~ X) ---\n")
print(summary(fit_a)$coefficients)
cat("\n--- b + c'-PAD (Y ~ X + M) ---\n")
print(summary(fit_bc)$coefficients)

# Decompositie: c = c' + a*b
a_hat   <- coef(fit_a)["eerdere_afwijzing"]
b_hat   <- coef(fit_bc)["sociale_voorzichtigheid"]
c_prime <- coef(fit_bc)["eerdere_afwijzing"]
c_total <- coef(fit_total)["eerdere_afwijzing"]
ab_hat  <- a_hat * b_hat

cat("\n--- DECOMPOSITIE ---\n")
cat(sprintf("a       = %.4f\n", a_hat))
cat(sprintf("b       = %.4f\n", b_hat))
cat(sprintf("a*b     = %.4f  (indirect-effect)\n", ab_hat))
cat(sprintf("c'      = %.4f  (direct-effect)\n", c_prime))
cat(sprintf("c'+ a*b = %.4f  (decompositie)\n", c_prime + ab_hat))
cat(sprintf("c       = %.4f  (totaal-effect)\n", c_total))

# Sobel handmatig.
s_a <- summary(fit_a)$coefficients["eerdere_afwijzing", "Std. Error"]
s_b <- summary(fit_bc)$coefficients["sociale_voorzichtigheid", "Std. Error"]
z_sobel <- (a_hat * b_hat) / sqrt(a_hat^2 * s_b^2 + b_hat^2 * s_a^2)
p_sobel <- 2 * (1 - pnorm(abs(z_sobel)))

cat(sprintf("\n--- SOBEL ---\n"))
cat(sprintf("z = %.3f, p = %.5f\n", z_sobel, p_sobel))

# -------- Suppressie-data: bouwvaardigheid -> perfectionisme -> snelheid

# Aparte slakken — geen overlap met slak_ontmoetingen (n = 80).
set.seed(20260513)
n2 <- 80

# X: bouwvaardigheid — algemene competentie (continu 0-100).
bouwvaardigheid <- rnorm(n2, mean = 55, sd = 14)

# M: perfectionisme — door bouwvaardigheid wordt slak ook perfectionistisch
# (je weet wat goed is, dus je bent kritischer). Positief a-pad.
perfectionisme  <- 20 + 0.55 * bouwvaardigheid + rnorm(n2, 0, 9)

# Y: actie_snelheid — bouwvaardigheid maakt sneller (c'-positief direct),
# maar perfectionisme remt actie (b-NEGATIEF). Klassieke suppressie.
# Y = 30 + 0.55*X - 0.55*M + ruis.
# Totaal-effect c = c' + a*b = 0.55 + 0.55*(-0.55) = 0.55 - 0.30 = 0.25.
# Dus |c| < |c'|: suppressor-symptoom.
actie_snelheid  <- 30 + 0.55 * bouwvaardigheid - 0.55 * perfectionisme +
  rnorm(n2, 0, 9)

bouwvaardigheid <- round(clip01(bouwvaardigheid), 2)
perfectionisme  <- round(clip01(perfectionisme),  2)
actie_snelheid  <- round(clip01(actie_snelheid),  2)

slak_suppressie <- data.frame(
  slak_id          = factor(sprintf("b%02d", seq_len(n2))),
  bouwvaardigheid  = bouwvaardigheid,
  perfectionisme   = perfectionisme,
  actie_snelheid   = actie_snelheid
)

cat("\n\n=== SLAK_SUPPRESSIE ===\n")
cat("--- structuur ---\n"); str(slak_suppressie)
cat("--- means + SD's ---\n")
print(round(sapply(slak_suppressie[, -1], mean), 2))
print(round(sapply(slak_suppressie[, -1], sd),   2))
cat("--- correlaties ---\n")
print(round(cor(slak_suppressie[, -1]), 3))

fit_total_s <- lm(actie_snelheid ~ bouwvaardigheid, data = slak_suppressie)
fit_a_s     <- lm(perfectionisme ~ bouwvaardigheid, data = slak_suppressie)
fit_bc_s    <- lm(actie_snelheid ~ bouwvaardigheid + perfectionisme,
                  data = slak_suppressie)

cat("\n--- c (suppressie) ---\n")
print(summary(fit_total_s)$coefficients)
cat("\n--- a (suppressie) ---\n")
print(summary(fit_a_s)$coefficients)
cat("\n--- b + c' (suppressie) ---\n")
print(summary(fit_bc_s)$coefficients)

a_s   <- coef(fit_a_s)["bouwvaardigheid"]
b_s   <- coef(fit_bc_s)["perfectionisme"]
cp_s  <- coef(fit_bc_s)["bouwvaardigheid"]
c_s   <- coef(fit_total_s)["bouwvaardigheid"]

cat(sprintf("\na = %.3f, b = %.3f, a*b = %.3f, c' = %.3f, c = %.3f\n",
            a_s, b_s, a_s*b_s, cp_s, c_s))
cat(sprintf("|c| = %.3f vs |c'| = %.3f  -- |c| < |c'| ?  %s\n",
            abs(c_s), abs(cp_s), abs(c_s) < abs(cp_s)))

# Sla beide objecten op in één RData.
save(slak_ontmoetingen, slak_suppressie,
     file = "data/slak_ontmoetingen.RData")
