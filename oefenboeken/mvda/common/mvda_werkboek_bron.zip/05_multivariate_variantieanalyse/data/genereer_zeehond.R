# Genereer zeehond_eilanden dataset voor het MANOVA-thema, R-practical E5.
#
# Dier-context: een ecoloog observeert zeehonden op drie typen eilanden
# (klif / strand / binnenmeer) en meet drie psychologische variabelen
# per zeehond.
#
# Eén factor (eilandtype, 3 niveaus), drie continue DV's:
#   - nieuwsgierigheid       (schaal 0-100)
#   - voorzichtigheid        (schaal 0-100)
#   - sociale_speelsheid     (schaal 0-100)
#
# Doelen:
#   - Multivariate effect significant: Pillai ~ .25-.40, p < .001
#   - Univariate F's: minstens 2 van de 3 significant na Bonferroni .017
#   - N = 84 zeehonden, ongeveer balanced (28 per groep)
#   - Box's M: niet alarmerend significant
#
# Reproduceerbaar via set.seed(20260509).

set.seed(20260509)

n_klif    <- 28
n_strand  <- 28
n_meer    <- 28
N <- n_klif + n_strand + n_meer

eilandtype <- factor(
  c(rep("klif", n_klif),
    rep("strand", n_strand),
    rep("binnenmeer", n_meer)),
  levels = c("klif", "strand", "binnenmeer")
)

# Cel-gemiddelden:
#   klif:        hoog voorzichtigheid, laag nieuwsgierigheid, laag speelsheid
#   strand:      hoog speelsheid, gemiddeld nieuwsgierigheid, laag voorzichtigheid
#   binnenmeer:  hoog nieuwsgierigheid, gemiddeld speelsheid, gemiddeld voorzichtig
mu <- list(
  klif        = c(nieuwsgierigheid = 38, voorzichtigheid = 72, sociale_speelsheid = 35),
  strand      = c(nieuwsgierigheid = 55, voorzichtigheid = 42, sociale_speelsheid = 70),
  binnenmeer  = c(nieuwsgierigheid = 70, voorzichtigheid = 55, sociale_speelsheid = 55)
)

sd_vec <- c(nieuwsgierigheid = 12, voorzichtigheid = 12, sociale_speelsheid = 12)
R_dv <- matrix(c(
   1.00,  -0.30,  0.25,
  -0.30,   1.00, -0.20,
   0.25,  -0.20,  1.00
), nrow = 3, byrow = TRUE)
Sigma <- diag(sd_vec) %*% R_dv %*% diag(sd_vec)

suppressPackageStartupMessages(library(MASS))

draw_group <- function(n, mu_g, Sigma_g) {
  Y <- MASS::mvrnorm(n = n, mu = mu_g, Sigma = Sigma_g)
  colnames(Y) <- c("nieuwsgierigheid", "voorzichtigheid", "sociale_speelsheid")
  Y
}

Y_klif   <- draw_group(n_klif,   mu$klif,       Sigma)
Y_strand <- draw_group(n_strand, mu$strand,     Sigma * 1.05)
Y_meer   <- draw_group(n_meer,   mu$binnenmeer, Sigma * 0.95)

Y_all <- rbind(Y_klif, Y_strand, Y_meer)

clip01 <- function(x) pmin(pmax(x, 0), 100)
Y_all <- apply(Y_all, 2, clip01)
Y_all <- round(Y_all, 1)

zeehond_eilanden <- data.frame(
  eilandtype          = eilandtype,
  nieuwsgierigheid    = Y_all[, "nieuwsgierigheid"],
  voorzichtigheid     = Y_all[, "voorzichtigheid"],
  sociale_speelsheid  = Y_all[, "sociale_speelsheid"]
)

# Snelle controles
cat("--- structuur ---\n"); str(zeehond_eilanden)
cat("--- N en celgroottes ---\n"); print(table(zeehond_eilanden$eilandtype))

cat("--- DV-means per groep ---\n")
print(aggregate(cbind(nieuwsgierigheid, voorzichtigheid, sociale_speelsheid) ~ eilandtype,
                data = zeehond_eilanden, FUN = mean))

# MANOVA
suppressPackageStartupMessages(library(car))
lm_man <- lm(cbind(nieuwsgierigheid, voorzichtigheid, sociale_speelsheid) ~ eilandtype,
             data = zeehond_eilanden)
res_Manova <- Manova(lm_man, type = 3)
cat("--- MANOVA summary ---\n")
print(summary(res_Manova, multivariate = TRUE, univariate = TRUE))

suppressPackageStartupMessages(library(rstatix))
cat("--- Box's M ---\n")
print(box_m(data  = zeehond_eilanden[, c("nieuwsgierigheid", "voorzichtigheid", "sociale_speelsheid")],
            group = zeehond_eilanden$eilandtype))

save(zeehond_eilanden, file = "data/zeehond_eilanden.RData")
