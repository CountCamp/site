# Genereer leeuw_gevoelens dataset voor het MANOVA-thema (5.1, 5.2).
#
# Dier-context: een leeuw observeert zijn troep en noteert per leeuw VIER
# gevoelens (trots, jaloezie, eenzaamheid, woede). De factor is sociale_status
# (alpha / midden / outsider). Vraag: verschillen die vier gevoelens samen
# tussen statusgroepen?
#
# Vier continue DV's, één factor met drie niveaus, N = 110 (36 / 38 / 36).
#
# Draaien vanuit de map 05_multivariate_variantieanalyse/ (dezelfde werkmap als
# het hoofdstuk), want het pad hieronder is relatief: data/leeuw_gevoelens.RData.
#
# ---- Waar dit script vandaan komt (10-10-2026) ------------------------------
#
# Tot 10-10-2026 stond hier het 3-DV-script uit mei (seed 20260508), byte voor
# byte gelijk aan genereer_leeuw_v0_3DV_2026-05-20.R. Wie het draaide, schreef
# over leeuw_gevoelens.RData heen en wiste daarmee `woede`, de vierde DV waar het
# hele hoofdstuk op rust.
#
# De 4-DV-data in leeuw_gevoelens.RData komen uit het Bib-script
#   countcamp_lab/bib/items/datasets/scripts/dataset-leeuw-gevoelens-scenario-X-generate.R
# (seed 2026; parameters in dataset-leeuw-gevoelens-scenario-X.yml v1.1). Het
# genereerdeel hieronder is daar regel voor regel uit overgenomen, inclusief de
# volgorde waarin de pakketten geladen worden -- die volgorde hoort bij de
# trekking, dus niet "opruimen". Veranderd zijn alleen het opslagpad (dat
# wees nog naar de oude map 2526_r_practicals/) en de controle vóór het
# opslaan.
#
# Nagemeten op broodje (R 4.6.0, MASS 7.3.65, OpenBLAS 0.3.33): dit script geeft
# dezelfde waarden als de bestaande leeuw_gevoelens.RData. Niet bit voor bit:
# 205 van de 440 cellen verschillen in de laatste bits, hoogstens 2.1e-14 op een
# schaal van 0 tot 100, en afgerond op tien decimalen zijn alle 440 gelijk. Dat
# verschil zit in de rekenbibliotheek (BLAS), niet in de data. Elk getal in het
# hoofdstuk komt er hetzelfde uit.
#
# Daarom overschrijft het script het bestaande bestand NIET als de waarden al
# gelijk zijn: anders verandert het .RData-bestand bij elke run op een andere
# machine een beetje, zonder dat er iets veranderd is. En als de waarden NIET
# gelijk zijn, stopt het script met een melding in plaats van stil te
# overschrijven -- dan is er iets anders aan de hand, en dat moet een mens zien.

set.seed(2026)

suppressPackageStartupMessages({
  library(MASS)
  library(car)
  library(candisc)
  library(rstatix)
})

# ----- Parameters (theorie-gedreven, uit de Bib-YAML v1.1) -----

means <- list(
  alpha    = c(trots = 80, jaloezie = 40, eenzaamheid = 25, woede = 45),
  midden   = c(trots = 55, jaloezie = 75, eenzaamheid = 50, woede = 70),
  outsider = c(trots = 25, jaloezie = 45, eenzaamheid = 75, woede = 30)
)

ns <- c(alpha = 36, midden = 38, outsider = 36)

sds <- c(trots = 9, jaloezie = 9, eenzaamheid = 9, woede = 9)

# Gedeelde correlatie-matrix BINNEN de groepen (Box's M niet-significant by
# design). Let op: dit zijn de doelen voor de samenhang binnen één statusgroep.
# De correlatiematrix over alle 110 leeuwen samen (zoals cor() in 5.1.a hem
# geeft) is een ander getal, want daar telt het verschil tussen de groepen mee.
# Tik deze doelen dus nooit over in het hoofdstuk -- reken ze daar uit.
cor_mat <- matrix(c(
   1.00, -0.20, -0.45, -0.15,
  -0.20,  1.00,  0.20,  0.55,
  -0.45,  0.20,  1.00,  0.15,
  -0.15,  0.55,  0.15,  1.00
), nrow = 4, byrow = TRUE)
dimnames(cor_mat) <- list(names(sds), names(sds))

cov_mat <- diag(sds) %*% cor_mat %*% diag(sds)
dimnames(cov_mat) <- dimnames(cor_mat)

# ----- Genereer per groep -----

generate_group <- function(grp_name) {
  X <- MASS::mvrnorm(n = ns[[grp_name]], mu = means[[grp_name]], Sigma = cov_mat)
  # Groepsgemiddelden exact op de doelen zetten (steekproefruis in het
  # gemiddelde wegrekenen). De SD's en correlaties blijven wél steekproefwaarden.
  X <- sweep(X, 2, colMeans(X))
  X <- sweep(X, 2, means[[grp_name]], FUN = "+")
  # Clip naar [0, 100]
  X <- pmin(pmax(X, 0), 100)
  data.frame(
    sociale_status = grp_name,
    trots          = X[, "trots"],
    jaloezie       = X[, "jaloezie"],
    eenzaamheid    = X[, "eenzaamheid"],
    woede          = X[, "woede"]
  )
}

leeuw_gevoelens <- do.call(rbind, lapply(names(means), generate_group))
leeuw_gevoelens$sociale_status <- factor(
  leeuw_gevoelens$sociale_status,
  levels = c("alpha", "midden", "outsider")
)

# ----- Snelle controles -----

dv <- c("trots", "jaloezie", "eenzaamheid", "woede")

cat("\n=== N per groep ===\n")
print(table(leeuw_gevoelens$sociale_status))

cat("\n=== Groepsgemiddelden en SD's ===\n")
print(aggregate(leeuw_gevoelens[, dv], list(status = leeuw_gevoelens$sociale_status), mean))
print(aggregate(leeuw_gevoelens[, dv], list(status = leeuw_gevoelens$sociale_status), sd))

cat("\n=== Box's M (doel: p > .001) ===\n")
print(rstatix::box_m(leeuw_gevoelens[, dv], leeuw_gevoelens$sociale_status))

cat("\n=== MANOVA: de vier multivariate toetsen ===\n")
options(contrasts = c("contr.sum", "contr.poly"))
lm_leeuw <- lm(cbind(trots, jaloezie, eenzaamheid, woede) ~ sociale_status,
               data = leeuw_gevoelens)
print(summary(car::Manova(lm_leeuw, type = 3), multivariate = TRUE, univariate = FALSE))

# Univariate F's via summary.aov(), NIET via univariate = TRUE: car rekent een
# deel van die F's verkeerd uit zodra de termen ongelijke df hebben (intercept
# df = 1, sociale_status df = 2). Zie de waarschuwing in 5.1.c van het hoofdstuk.
cat("\n=== Univariate F per DV (summary.aov) ===\n")
print(summary.aov(lm_leeuw))

cat("\n=== DDA ===\n")
DA <- candisc::candisc(lm_leeuw)
print(DA)
print(round(DA$structure, 3))

# ----- Bewaren, maar nooit stil overschrijven -----

uit <- "data/leeuw_gevoelens.RData"
if (file.exists(uit)) {
  oud <- new.env()
  load(uit, envir = oud)
  gelijk <- isTRUE(all.equal(leeuw_gevoelens, oud$leeuw_gevoelens, tolerance = 1e-10))
  if (gelijk) {
    cat(sprintf("\n[OK] %s bestaat al en heeft dezelfde waarden (tot op 1e-10).",
                uit), "Niet overschreven.\n")
  } else {
    stop("Dit script geeft ANDERE waarden dan het bestaande ", uit, ".\n",
         "  Niet overschreven. Vergelijk eerst met all.equal(); als het",
         " verschil echt bedoeld is, verwijder dan het oude bestand met de hand",
         " en draai opnieuw.")
  }
} else {
  save(leeuw_gevoelens, file = uit)
  cat(sprintf("\n[OK] Data opgeslagen: %s (%d leeuwen)\n", uit, nrow(leeuw_gevoelens)))
}
