# Genereer leeuw_gevoelens dataset voor het MANOVA-thema (5.1, 5.2).
#
# Dier-context: een leeuw observeert zijn troep en noteert per leeuw drie
# gevoelens (trots, jaloezie, eenzaamheid). De factor is sociale_status
# (alpha / middenrang / outsider). Vraag: verschillen die drie gevoelens
# samen tussen statusgroepen?
#
# Drie continue DV's, één factor met drie niveaus.
#
# Doelen voor de kalibratie:
#   - alpha:        hoog trots, lage jaloezie, lage eenzaamheid
#   - middenrang:   gemiddeld trots, hoogste jaloezie, gemiddelde eenzaamheid
#   - outsider:     laagste trots, lage jaloezie, hoogste eenzaamheid
#   - Multivariate effect significant: Pillai ~ .35-.50, p < .001
#   - Univariate F per DV: alledrie significant in verschillende richting
#   - Bonferroni op alpha = .05/3 = .017: alle drie blijven significant
#   - Box's M: niet alarmerend significant (p > .001 — Leiden's strenge alpha)
#   - Cellen ongeveer balanced (35-40 per groep), N = 110
#
# Reproduceerbaar via set.seed(20260508).

set.seed(20260508)

# Cel-groottes — ongeveer balanced.
n_alpha <- 36
n_mid   <- 38
n_out   <- 36
N <- n_alpha + n_mid + n_out

sociale_status <- factor(
  c(rep("alpha", n_alpha),
    rep("middenrang", n_mid),
    rep("outsider", n_out)),
  levels = c("alpha", "middenrang", "outsider")
)

# Cel-gemiddelden voor de drie DV's (schaal 0-100).
#   trots: alpha hoog, middenrang medium, outsider laag
#   jaloezie: alpha laag, middenrang hoog, outsider laag
#   eenzaamheid: alpha laag, middenrang medium, outsider hoog
mu <- list(
  alpha       = c(trots = 78, jaloezie = 32, eenzaamheid = 28),
  middenrang  = c(trots = 58, jaloezie = 65, eenzaamheid = 50),
  outsider    = c(trots = 42, jaloezie = 38, eenzaamheid = 72)
)

# Gedeelde residuele covariantie-matrix — geen extreme schending van
# Box's M, maar wel realistische correlaties tussen de DV's:
#   trots ~ jaloezie:    licht positief (.20)
#   trots ~ eenzaamheid: licht negatief (-.25)
#   jaloezie ~ eenz.:    licht positief (.30)
sd_vec <- c(trots = 14, jaloezie = 14, eenzaamheid = 14)
R_dv <- matrix(c(
   1.00,  0.20, -0.25,
   0.20,  1.00,  0.30,
  -0.25,  0.30,  1.00
), nrow = 3, byrow = TRUE)
Sigma <- diag(sd_vec) %*% R_dv %*% diag(sd_vec)

# Trekking per groep met MASS::mvrnorm.
suppressPackageStartupMessages(library(MASS))

draw_group <- function(n, mu_g, Sigma_g) {
  Y <- MASS::mvrnorm(n = n, mu = mu_g, Sigma = Sigma_g)
  colnames(Y) <- c("trots", "jaloezie", "eenzaamheid")
  Y
}

Y_alpha <- draw_group(n_alpha, mu$alpha,      Sigma)
Y_mid   <- draw_group(n_mid,   mu$middenrang, Sigma * 1.10)  # iets meer spreiding
Y_out   <- draw_group(n_out,   mu$outsider,   Sigma * 0.95)

Y_all <- rbind(Y_alpha, Y_mid, Y_out)

# Clip op [0, 100] en rond af op 1 decimaal.
clip01 <- function(x) pmin(pmax(x, 0), 100)
Y_all <- apply(Y_all, 2, clip01)
Y_all <- round(Y_all, 1)

leeuw_gevoelens <- data.frame(
  sociale_status = sociale_status,
  trots          = Y_all[, "trots"],
  jaloezie       = Y_all[, "jaloezie"],
  eenzaamheid    = Y_all[, "eenzaamheid"]
)

# Snelle controles
cat("--- structuur ---\n"); str(leeuw_gevoelens)
cat("--- N en celgroottes ---\n"); print(table(leeuw_gevoelens$sociale_status))

cat("--- DV-means per groep ---\n")
print(aggregate(cbind(trots, jaloezie, eenzaamheid) ~ sociale_status,
                data = leeuw_gevoelens, FUN = mean))

cat("--- DV-SD's per groep ---\n")
print(aggregate(cbind(trots, jaloezie, eenzaamheid) ~ sociale_status,
                data = leeuw_gevoelens, FUN = sd))

cat("--- correlatiematrix DV's (totaal) ---\n")
print(round(cor(leeuw_gevoelens[, c("trots", "jaloezie", "eenzaamheid")]), 2))

# MANOVA fitten — vier teststatistics.
lm_man <- lm(cbind(trots, jaloezie, eenzaamheid) ~ sociale_status,
             data = leeuw_gevoelens)
suppressPackageStartupMessages(library(car))
res_Manova <- Manova(lm_man, type = 3)
cat("--- MANOVA summary (multivariate + univariate) ---\n")
print(summary(res_Manova, multivariate = TRUE, univariate = TRUE))

# Box's M.
suppressPackageStartupMessages(library(rstatix))
cat("--- Box's M ---\n")
print(box_m(data  = leeuw_gevoelens[, c("trots", "jaloezie", "eenzaamheid")],
            group = leeuw_gevoelens$sociale_status))

# Univariate ANOVA's (zonder Bonferroni).
cat("--- univariate F (zonder Bonferroni) ---\n")
print(summary.aov(lm_man))

# Discriminant Analysis (descriptive) via candisc::candisc
suppressPackageStartupMessages({
  if (requireNamespace("candisc", quietly = TRUE)) {
    library(candisc)
    DA <- candisc(lm_man)
    cat("--- candisc — eigenvalues + structure ---\n")
    print(DA)
    print(summary(DA))
  }
})

save(leeuw_gevoelens, file = "data/leeuw_gevoelens.RData")
