#==============================================================================
# Twee landen, dezelfde sporters — data-generatie voor T9
#
# Drie soorten sporters (ballerina / turnster / bodybuilder), vijf per soort,
# in twee landen (Nederland, Rusland). Twee maten per sporter: uithouding en
# bloeddruk. 3 soorten x 5 sporters x 2 landen = 30 rijen. Verzonnen data, klein
# genoeg om met pen en papier door te rekenen.
#
# Geen toeval, alles gekozen. Elke sporter wijkt met een heel getal af van het
# gemiddelde van zijn soort, en die afwijkingen zijn in elke soort dezelfde vijf.
#
# WAT DE TEKST BELOOFT (T9, en kader A, "tweede geval"):
#
# - Per soort zijn gemiddelde EN standaardafwijking in beide landen precies
#   gelijk, op allebei de maten. Daardoor zijn de twee losse ANOVA's in beide
#   landen dezelfde: F(2, 12) = 2.00, p = .18 -- niet significant.
# - Het enige verschil tussen de landen is de samenhang BINNEN een soort: in
#   Nederland r = +.80 (meer uithouding, hogere bloeddruk), in Rusland r = -.80.
#   Dat komt doordat de Russische afwijkingen op bloeddruk precies het
#   tegengestelde zijn van de Nederlandse (afw_ru <- -afw_nl).
# - De drie soortgemiddelden liggen op één rechte lijn: van ballerina naar
#   bodybuilder gaat uithouding steeds 1 omlaag en bloeddruk 1 omhoog. Daarom
#   is er maar één discriminantfunctie die iets doet, en is dat precies de
#   verschilscore uithouding - bloeddruk (gewichten 1 en -1).
# - In Nederland ligt dat verschil tussen de soorten dwars op de samenhang
#   binnen de soorten: de verschilscore heeft daar weinig ruis, en de MANOVA is
#   significant (Wilks' Lambda = .231). In Rusland loopt het verschil met de
#   samenhang mee: veel ruis, MANOVA niet significant (Lambda = .730).
#
# De volgorde van de rijen ligt vast en is niet gesorteerd (volg), zodat een
# student in de tabel niet meteen een trapje ziet. Een paar (uithouding,
# bloeddruk) van één sporter blijft altijd bij elkaar.
#
# Draai vanuit de hoofdstukmap:
#   Rscript data/genereer_sporters.R
#==============================================================================

suppressPackageStartupMessages(library(car))   # Manova
options(contrasts = c("contr.sum", "contr.poly"))

# ----- De bouwstenen ---------------------------------------------------------

afw_x  <- c(-2, -1, 0, 1, 2)            # afwijking van het soortgemiddelde, uithouding
afw_nl <- c(-1, -2, 0, 2, 1)            # bloeddruk in Nederland: r binnen = +.8
afw_ru <- -afw_nl                       # bloeddruk in Rusland:   r binnen = -.8
gem <- rbind(ballerina   = c(8, 5),     # (uithouding, bloeddruk)
             turnster    = c(7, 6),
             bodybuilder = c(6, 7))
volg <- c(3, 1, 5, 2, 4)                # vaste, ongesorteerde rijvolgorde

soorten <- rownames(gem)
landen  <- c("Nederland", "Rusland")
afw_y   <- list(Nederland = afw_nl, Rusland = afw_ru)

# ----- De dataset ------------------------------------------------------------

sporters <- do.call(rbind, lapply(landen, function(l) {
  do.call(rbind, lapply(soorten, function(s) {
    data.frame(
      land       = factor(l, levels = landen),
      soort      = factor(s, levels = soorten),
      uithouding = gem[s, 1] + afw_x[volg],
      bloeddruk  = gem[s, 2] + afw_y[[l]][volg]
    )
  }))
}))
rownames(sporters) <- NULL

# ----- Bewijs dat de data doen wat de tekst belooft --------------------------

per_land <- split(sporters, sporters$land)
anova_F  <- function(d) sapply(summary.aov(lm(cbind(uithouding, bloeddruk) ~ soort, data = d)),
                               function(x) x[["F value"]][1])
wilks    <- function(d) {
  res <- Manova(lm(cbind(uithouding, bloeddruk) ~ soort, data = d), type = 3)
  eig <- Re(eigen(solve(res$SSPE) %*% res$SSP$soort)$values)
  car:::Wilks(eig, res$df[["soort"]], res$error.df)[1]
}
r_binnen <- function(d) sapply(split(d, d$soort), function(x) cor(x$uithouding, x$bloeddruk))

stopifnot(
  "30 rijen: 3 soorten x 5 sporters x 2 landen" = nrow(sporters) == 30,
  "per soort gelijke gemiddelden en SD's in beide landen" =
    isTRUE(all.equal(
      aggregate(cbind(uithouding, bloeddruk) ~ soort, per_land$Nederland, function(x) c(mean(x), sd(x))),
      aggregate(cbind(uithouding, bloeddruk) ~ soort, per_land$Rusland,   function(x) c(mean(x), sd(x))))),
  "elke losse ANOVA geeft F = 2.00, in beide landen" =
    isTRUE(all.equal(unname(c(anova_F(per_land$Nederland), anova_F(per_land$Rusland))), rep(2, 4))),
  "r binnen elke soort: +.80 in Nederland, -.80 in Rusland" =
    isTRUE(all.equal(unname(r_binnen(per_land$Nederland)), rep(.8, 3))) &&
    isTRUE(all.equal(unname(r_binnen(per_land$Rusland)), rep(-.8, 3))),
  "Wilks' Lambda = 12/52 in Nederland en 108/148 in Rusland" =
    isTRUE(all.equal(unname(wilks(per_land$Nederland)), 12 / 52)) &&
    isTRUE(all.equal(unname(wilks(per_land$Rusland)), 108 / 148))
)

print(aggregate(cbind(uithouding, bloeddruk) ~ land + soort, sporters, mean))
cat("Wilks' Lambda: Nederland =", round(wilks(per_land$Nederland), 3),
    "| Rusland =", round(wilks(per_land$Rusland), 3), "\n")

# ----- Bewaar ----------------------------------------------------------------

save(sporters, file = "data/sporters_twee_landen.RData")
cat("\n[OK] data/sporters_twee_landen.RData opgeslagen\n")
