#==============================================================================
# Tulpen-oogst — data-generatie voor opgave 5.2-voorzet
#
# Drie tulpensoorten (Tulipa univariegata / multivariegata / variabilis) over
# twee oogstjaren (2023, 2024). Twee morfometrische DV's: steellengte (cm),
# kelkdiameter (mm). N=30 per soort, totaal 90 per oogstjaar.
#
# DIDACTISCHE CLOU (synthetisch + gestileerd):
# - Subtle groeps-mean-verschillen per soort. Univariate-ANOVA-power per DV
#   onder drempel (F < 2, p > .15). Marginal-mean-tabel ziet er VRIJWEL
#   identiek uit per oogstjaar.
# - Jaar 2023: groepsgewijze correlaties verschillen sterk per soort
#   (univariegata r=-.7, multivariegata r=+.7, variabilis r=0).
#   Het verschil zit in DIAGONALE richting en wordt door cov-structuur
#   versterkt → MANOVA SIG (Pillai p < .05).
# - Jaar 2024: groepsgewijze correlaties identiek over soorten (r=+.3 voor alle).
#   Versterking ontbreekt → MANOVA NIET sig.
#
# WISKUNDIGE NUANCE: bij EXACT identieke groeps-means is MANOVA per definitie
# niet significant (sample H-matrix ≈ 0). Bens originele claim van "identieke
# means met multivariaat verschil" is een didactische idealisering. Wij maken
# het werkbaar met SUBTLE groeps-verschillen die per-DV-univariaat onder de
# significantie-drempel blijven (p > .10) maar via cov-structuur multivariaat
# wel opduiken.
#
# In echte tulpen-data zou je per-soort grotere marginal-mean-verschillen
# verwachten. Dit voorbeeld is didactisch gestileerd om de multivariate-vs-
# univariate-power-clou (verbonden aan stelling B uit MANOVA-callout A)
# scherp te krijgen.
#==============================================================================

set.seed(2026)

suppressPackageStartupMessages({
  library(MASS)   # mvrnorm
  library(car)    # Manova
})

# ----- Parameters (gedeeld) -----

n_per_soort <- 30
soorten     <- c("univariegata", "multivariegata", "variabilis")
sds         <- c(steellengte = 6,  kelkdiameter = 8)

# Subtile groeps-means — verschillen klein (3-4 punten op een schaal van 40)
# en in een diagonale richting (steel en kelk samen verschillend per soort).
# Per-DV F < 2, p > .10 verwacht. Multivariate richting samen kan wel oppikken.
mu_per_soort <- list(
  univariegata   = c(steellengte = 38, kelkdiameter = 68),  # korte steel, wijde kelk
  multivariegata = c(steellengte = 40, kelkdiameter = 65),  # midden / standaard
  variabilis     = c(steellengte = 42, kelkdiameter = 62)   # lange steel, smalle kelk
)

# ----- Helper: maak cov-matrix uit cor + sds -----

cov_from_cor <- function(r, s) {
  m <- matrix(c(1, r, r, 1), nrow = 2)
  diag(s) %*% m %*% diag(s)
}

# ----- Oogst 2023: verschillende correlaties per soort -----

cor_2023 <- list(
  univariegata   = -0.70,   # korte steel ↔ wijde kelk (sterk negatief)
  multivariegata = +0.70,   # lange steel ↔ wijde kelk (sterk positief)
  variabilis     =  0.00    # ongecorreleerd
)

# ----- Oogst 2024: identieke correlatie over soorten -----

cor_2024 <- list(
  univariegata   = +0.30,
  multivariegata = +0.30,
  variabilis     = +0.30
)

# ----- Genereer per oogst per soort -----

generate_year <- function(cors_by_soort, year_label) {
  do.call(rbind, lapply(soorten, function(s) {
    Sigma <- cov_from_cor(cors_by_soort[[s]], sds)
    X <- MASS::mvrnorm(n = n_per_soort, mu = mu_per_soort[[s]], Sigma = Sigma)
    # Force exact means per groep (centreer-en-schaal)
    X <- sweep(X, 2, colMeans(X))
    X <- sweep(X, 2, mu_per_soort[[s]], FUN = "+")
    data.frame(
      soort        = s,
      steellengte  = X[, 1],
      kelkdiameter = X[, 2]
    )
  }))
}

tulpen_2023 <- generate_year(cor_2023, 2023)
tulpen_2023$soort <- factor(tulpen_2023$soort, levels = soorten)

tulpen_2024 <- generate_year(cor_2024, 2024)
tulpen_2024$soort <- factor(tulpen_2024$soort, levels = soorten)

# ----- Verifieer: marginal means identiek over jaren -----

cat("\n=== Marginal means (per soort) — 2023 ===\n")
print(round(aggregate(cbind(steellengte, kelkdiameter) ~ soort,
                       data = tulpen_2023, mean)[, -1], 2))

cat("\n=== Marginal means (per soort) — 2024 ===\n")
print(round(aggregate(cbind(steellengte, kelkdiameter) ~ soort,
                       data = tulpen_2024, mean)[, -1], 2))

# ----- Verifieer: within-soort correlaties (2023) -----

cat("\n=== Within-soort correlaties — oogst 2023 ===\n")
for (s in soorten) {
  sub <- subset(tulpen_2023, soort == s)
  r <- cor(sub$steellengte, sub$kelkdiameter)
  cat(sprintf("  %-15s r = %+.3f\n", s, r))
}

cat("\n=== Within-soort correlaties — oogst 2024 ===\n")
for (s in soorten) {
  sub <- subset(tulpen_2024, soort == s)
  r <- cor(sub$steellengte, sub$kelkdiameter)
  cat(sprintf("  %-15s r = %+.3f\n", s, r))
}

# ----- MANOVA-check oogst 2023 (verwacht SIG) -----

cat("\n=== MANOVA — oogst 2023 (verwacht: SIG) ===\n")
options(contrasts = c("contr.sum", "contr.poly"))
lm_2023 <- lm(cbind(steellengte, kelkdiameter) ~ soort, data = tulpen_2023)
man_2023 <- car::Manova(lm_2023, type = 3)
print(summary(man_2023, multivariate = TRUE, univariate = FALSE))

cat("\n=== Univariate ANOVA's — oogst 2023 (verwacht: NIET sig per DV) ===\n")
print(summary.aov(lm_2023))

# ----- MANOVA-check oogst 2024 (verwacht NIET sig) -----

cat("\n=== MANOVA — oogst 2024 (verwacht: NIET sig) ===\n")
lm_2024 <- lm(cbind(steellengte, kelkdiameter) ~ soort, data = tulpen_2024)
man_2024 <- car::Manova(lm_2024, type = 3)
print(summary(man_2024, multivariate = TRUE, univariate = FALSE))

cat("\n=== Univariate ANOVA's — oogst 2024 (verwacht: NIET sig per DV) ===\n")
print(summary.aov(lm_2024))

# ----- Bewaar -----

save(tulpen_2023, file = "data/tulpen_2023.RData")
save(tulpen_2024, file = "data/tulpen_2024.RData")
cat("\n[OK] Data opgeslagen: tulpen_2023.RData + tulpen_2024.RData\n")
cat("[OK] set.seed: 2026\n")
