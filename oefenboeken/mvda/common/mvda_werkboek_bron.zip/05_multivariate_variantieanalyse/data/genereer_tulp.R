#==============================================================================
# Tulpen-oogst — data-generatie voor 5.2.d
#
# Drie tulpensoorten (Tulipa univariegata / multivariegata / variabilis) over
# twee oogstjaren (2023, 2024). Twee maten per tulp: steellengte (cm) en
# kelkdiameter (mm). 30 tulpen per soort, 90 per oogstjaar.
#
# WAT DE TEKST BELOOFT (kader A, "Als H0 niet waar is", en de opening van
# 5.2.d): twee datasets met dezelfde groepsgemiddelden, waar het multivariate
# antwoord toch verschilt. Deze generator maakt het letterlijk waar:
#
# - Per soort zijn gemiddelde EN standaardafwijking in beide jaren precies
#   gelijk (afgedwongen, niet getrokken). Daardoor zijn de twee univariate
#   ANOVA-tabellen in beide jaren tot op de laatste decimaal hetzelfde.
# - Tussen de soorten verschillen de gemiddelden een beetje, te weinig om per
#   maat significant te zijn (p > .10 voor allebei).
# - Wat verschilt tussen de jaren is alleen de samenhang tussen steel en kelk
#   BINNEN een soort: in 2023 rond r = +.8 (een flinke tulp is lang en wijd),
#   in 2024 rond r = -.8 (een droog jaar: wat een bol in zijn steel stak, hield
#   hij niet over voor zijn kelk).
# - De soorten verschillen in de richting "lange steel, smalle kelk" tegenover
#   "korte steel, wijde kelk". In 2023 loopt dat dwars op de samenhang binnen de
#   soorten, en dan valt het verschil op: MANOVA significant. In 2024 loopt het
#   met die samenhang mee, en dan verdrinkt het in de gewone variatie: MANOVA
#   niet significant.
# - Binnen één jaar hebben de drie soorten ongeveer dezelfde samenhang. Dat
#   houdt de aanname van gelijke covariantiematrices heel. Geef je elke soort
#   een eigen samenhang (bijvoorbeeld -.7 / +.7 / 0), dan schend je precies de
#   aanname waar het hoofdstuk Box's M voor leert.
#
# Waarom gelijk TUSSEN DE JAREN en niet tussen de soorten: als de soorten
# binnen een jaar exact dezelfde gemiddelden hebben, is de hypothese-matrix nul
# en is elke multivariate toets nul. De samenhang binnen de soorten bepaalt hoe
# scherp MANOVA een verschil in gemiddelden ziet, niet of er een verschil is.
#
# Draai vanuit de hoofdstukmap:
#   Rscript data/genereer_tulp.R
#==============================================================================

suppressPackageStartupMessages({
  library(MASS)   # mvrnorm
  library(car)    # Manova
})
options(contrasts = c("contr.sum", "contr.poly"))

# ----- Parameters (gedeeld door beide jaren) ---------------------------------

n_per_soort <- 30
soorten     <- c("univariegata", "multivariegata", "variabilis")
sd_doel     <- c(steellengte = 6, kelkdiameter = 8)

# Kleine verschillen, en de drie punten liggen net niet op één lijn (anders is
# de tweede discriminantfunctie precies nul).
mu_per_soort <- list(
  univariegata   = c(steellengte = 39.6, kelkdiameter = 66.4),  # korte steel, wijde kelk
  multivariegata = c(steellengte = 41.4, kelkdiameter = 65.0),  # ertussenin
  variabilis     = c(steellengte = 42.0, kelkdiameter = 62.6)   # lange steel, smalle kelk
)

# .8 en niet .7: bij .7 kwam kelkdiameter op de eerste discriminantfunctie uit
# op een structuurcorrelatie van .399, pal onder de grens van .40 die het
# hoofdstuk hanteert. Dan leest een student ".40" en
# weet hij niet aan welke kant hij zit. Bij .8 liggen beide maten er ruim onder.
r_doel <- c(`2023` = +0.80, `2024` = -0.80)
seed   <- c(`2023` = 2026,  `2024` = 3026)

# ----- Eén oogstjaar ---------------------------------------------------------

maak_oogst <- function(jaar) {
  set.seed(seed[[jaar]])
  r <- r_doel[[jaar]]
  Sigma <- diag(sd_doel) %*% matrix(c(1, r, r, 1), 2) %*% diag(sd_doel)
  do.call(rbind, lapply(soorten, function(s) {
    X <- MASS::mvrnorm(n = n_per_soort, mu = c(0, 0), Sigma = Sigma)
    # Gemiddelde en SD per soort precies op het doel zetten. De samenhang
    # tussen de twee kolommen blijft die van de trekking.
    X <- scale(X)
    X <- sweep(X, 2, sd_doel, "*")
    X <- sweep(X, 2, mu_per_soort[[s]], "+")
    data.frame(
      soort        = factor(s, levels = soorten),
      steellengte  = X[, 1],
      kelkdiameter = X[, 2]
    )
  }))
}

tulpen_2023 <- maak_oogst("2023")
tulpen_2024 <- maak_oogst("2024")

# ----- Bewijs dat de data doen wat de tekst belooft --------------------------

anova_tab <- function(d) {
  sa <- summary.aov(lm(cbind(steellengte, kelkdiameter) ~ soort, data = d))
  sapply(sa, function(x) c(F = x[["F value"]][1], p = x[["Pr(>F)"]][1]))
}
pillai_p <- function(d) {
  res <- Manova(lm(cbind(steellengte, kelkdiameter) ~ soort, data = d), type = 3)
  eig <- Re(eigen(solve(res$SSPE) %*% res$SSP$soort)$values)
  v   <- car:::Pillai(eig, res$df[["soort"]], res$error.df)
  pf(v[2], v[3], v[4], lower.tail = FALSE)
}
r_binnen <- function(d) sapply(split(d, d$soort),
                               function(x) cor(x$steellengte, x$kelkdiameter))

a23 <- anova_tab(tulpen_2023); a24 <- anova_tab(tulpen_2024)
stopifnot(
  "per soort zijn gemiddelden en SD's in beide jaren gelijk" =
    isTRUE(all.equal(
      aggregate(cbind(steellengte, kelkdiameter) ~ soort, tulpen_2023, function(x) c(mean(x), sd(x))),
      aggregate(cbind(steellengte, kelkdiameter) ~ soort, tulpen_2024, function(x) c(mean(x), sd(x))))),
  "de univariate ANOVA's zijn in beide jaren gelijk" = isTRUE(all.equal(a23, a24)),
  "geen van beide maten is los significant, ook niet op .10" = all(a23["p", ] > .10),
  "2023: MANOVA significant op .001" = pillai_p(tulpen_2023) < .001,
  "2024: MANOVA niet significant, ook niet op .10" = pillai_p(tulpen_2024) > .10,
  "2023: binnen elke soort een duidelijk positieve samenhang" = all(r_binnen(tulpen_2023) > .50),
  "2024: binnen elke soort een duidelijk negatieve samenhang" = all(r_binnen(tulpen_2024) < -.50),
  "2023: geen van beide maten komt op de eerste discriminantfunctie in de buurt van de grens .40" =
    all(abs(candisc::candisc(lm(cbind(steellengte, kelkdiameter) ~ soort,
                                data = tulpen_2023))$structure[, 1]) < .37)
)

cat("\nUnivariaat (beide jaren gelijk):\n"); print(round(a23, 4))
cat("\nPillai p: 2023 =", signif(pillai_p(tulpen_2023), 3),
    "| 2024 =", signif(pillai_p(tulpen_2024), 3), "\n")
cat("r binnen de soorten 2023:", round(r_binnen(tulpen_2023), 2), "\n")
cat("r binnen de soorten 2024:", round(r_binnen(tulpen_2024), 2), "\n")

# ----- Bewaar ----------------------------------------------------------------

save(tulpen_2023, file = "data/tulpen_2023.RData")
save(tulpen_2024, file = "data/tulpen_2024.RData")
cat("\n[OK] data/tulpen_2023.RData en data/tulpen_2024.RData opgeslagen\n")
