# Genereer mol_werkdag dataset voor het ANOVA-thema, secties 2.1 en 2.2.
#
# Dier-context: een mol houdt per uur bij hoeveel centimeter hij graaft.
# Het is werk, hij houdt het bij. Twee factoren:
#   - gang_diepte (ondiep / diep)  — A, rij-factor; biologisch plausibel:
#     diepere bodem is compacter, dus daar graaft hij langzamer.
#   - dagdeel (ochtend / avond)    — B, kolom-factor; in de avond iets actiever.
# Design: 2 x 2 factorial, licht ongebalanceerd. N = 198.
#
# Verwachte kwaliteiten (kalibreer-doelen):
#   - hoofdeffect gang_diepte:  duidelijk significant, eta^2 ~ .15-.25
#   - hoofdeffect dagdeel:      borderline / matig,    eta^2 ~ .03-.06
#   - interactie:               klein-significant,     eta^2 ~ .02-.04
#     (verschil ondiep-vs-diep groter in avond dan in ochtend)
#
# Met set.seed(20260505) reproduceerbaar; sd en cel-gemiddelden zijn na een
# kleine grid-search vastgezet zodat de F/p-uitkomsten op de doelranges landen.

set.seed(20260505)

# Cel-aantallen: licht ongebalanceerd (verschillen 2-5 in n).
celgroottes <- c(
  "ondiep-ochtend" = 52,
  "ondiep-avond"   = 47,
  "diep-ochtend"   = 49,
  "diep-avond"     = 50
)
N <- sum(celgroottes)   # 198

gang_diepte <- factor(c(
  rep("ondiep", celgroottes[["ondiep-ochtend"]]),
  rep("ondiep", celgroottes[["ondiep-avond"]]),
  rep("diep",   celgroottes[["diep-ochtend"]]),
  rep("diep",   celgroottes[["diep-avond"]])
), levels = c("ondiep", "diep"))

dagdeel <- factor(c(
  rep("ochtend", celgroottes[["ondiep-ochtend"]]),
  rep("avond",   celgroottes[["ondiep-avond"]]),
  rep("ochtend", celgroottes[["diep-ochtend"]]),
  rep("avond",   celgroottes[["diep-avond"]])
), levels = c("ochtend", "avond"))

# Cel-gemiddelden in cm/uur graaftempo.
# - ondiep duidelijk sneller dan diep (groot hoofdeffect gang_diepte)
# - avond gemiddeld sneller dan ochtend (matig hoofdeffect dagdeel)
# - verschil ondiep-vs-diep groter in avond dan in ochtend (interactie)
cel_means <- c(
  "ondiep-ochtend" = 26,
  "ondiep-avond"   = 33,
  "diep-ochtend"   = 19,
  "diep-avond"     = 22
)

cel_id      <- paste(as.character(gang_diepte), as.character(dagdeel), sep = "-")
mu_per_mol  <- cel_means[cel_id]

# Eerst draw met de set.seed(20260505) hierboven; daarna nog een lokale seed-jump
# zodat het patroon op de gewenste F/p uitkomt zonder dat we N of cel-aantallen
# moeten aanpassen.
set.seed(68)

graaftempo  <- round(mu_per_mol + rnorm(N, mean = 0, sd = 10))

mol_werkdag <- data.frame(
  graaftempo  = as.integer(graaftempo),
  gang_diepte = gang_diepte,
  dagdeel     = dagdeel
)

# Snelle controles
cat("--- structuur ---\n"); str(mol_werkdag)
cat("--- celtellingen ---\n")
print(table(mol_werkdag$gang_diepte, mol_werkdag$dagdeel))
cat("--- celgemiddelden ---\n")
print(aggregate(graaftempo ~ gang_diepte * dagdeel,
                data = mol_werkdag, FUN = mean))

# 2x2 ANOVA — toets de drie effecten.
options(contrasts = c("contr.sum", "contr.poly"))
m <- lm(graaftempo ~ gang_diepte * dagdeel, data = mol_werkdag)
cat("--- Anova type III ---\n"); print(car::Anova(m, type = 3))
cat("--- eta^2 / partial eta^2 ---\n"); print(lsr::etaSquared(m))

# Eenweg-versie ter check (alleen gang_diepte).
m1 <- lm(graaftempo ~ gang_diepte, data = mol_werkdag)
cat("--- Eenweg gang_diepte ---\n"); print(car::Anova(m1, type = 3))
cat("--- eta^2 eenweg ---\n"); print(lsr::etaSquared(m1))

cat("--- Levene 2x2 ---\n")
print(car::leveneTest(graaftempo ~ gang_diepte * dagdeel, data = mol_werkdag))

cat("--- Levene eenweg ---\n")
print(car::leveneTest(graaftempo ~ gang_diepte, data = mol_werkdag))

save(mol_werkdag, file = "data/mol_werkdag.RData")
