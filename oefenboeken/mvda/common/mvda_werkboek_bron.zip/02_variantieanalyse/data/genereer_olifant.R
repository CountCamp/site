# Genereer olifant_geheugen dataset voor het ANOVA-thema, secties 2.3 en 2.4.
#
# Waarom deze dataset zo is. Na het 2 x 2 van de mol (secties 2.1 en 2.2)
# laat deze data dezelfde analyse op een ander object zien: een 2 x 3, met
# een factor van drie niveaus, zodat post-hoc-toetsen (Tukey) en een gepland
# contrast nodig en zinvol worden. De uitkomst is een telling (onthouden
# voorwerpen, 0 tot 40), de eerste factor een eigenschap die niet te loten
# valt (leeftijd), de tweede een geloot tussenstuk in drie soorten (slaap).
# Met dit script erbij kun je zelf nagaan hoe ze gemaakt zijn.
#
# Dier-context: de olifant, die nooit iets vergeet, wil weten of anderen dat
# ook niet doen. Hij legt elk dier een rij van veertig voorwerpen voor (een
# eikel, een veer, een steentje ...) en vraagt later hoeveel het er nog weet.
# Wat er tussen kijken en navragen gebeurt, bepaalt hij met een dobbelsteen:
#   - slaap (wakker / dutje / nachtslaap) -- B, kolomfactor, drie niveaus;
#     'wakker' is de vergelijkingsgroep, de twee andere zijn twee soorten slaap.
#   - leeftijd (jong / oud)               -- A, rijfactor; die kon hij niet
#     loten, die noteerde hij.
# Design: 2 x 3 factorial, licht ongebalanceerd. N = 126.
#
# Wat de tekst van hoofdstuk 2 van deze data vraagt, en wat dit script dus
# hieronder TOETST (stopifnot), zodat een nieuw zaad of een andere
# R-versie niet stil een andere les oplevert:
#   - slaap: duidelijk significant;
#   - leeftijd: niet significant (het hoofdeffect verbergt een kruising);
#   - interactie: significant -- wakker geen verschil, na een dutje
#     onthouden de oude dieren meer, na een nachtslaap de jonge;
#   - Tukey op slaap: wakker verschilt van dutje en van nachtslaap, dutje en
#     nachtslaap onderling niet; het geplande contrast op dat laatste paar
#     (zonder correctie voor drie paren) wél -- het punt van 2.4;
#   - de grootste spreiding zit in de kleinste cel (het voorbeeld bij de
#     richtingsregel), maar n_max/n_min < 1.5 en s_max/s_min < 2, en elke
#     cel heeft minstens 15 dieren: de F-toets is te vertrouwen.
#
# Het zaad is gevonden met een zoektocht tegen die eisen (iets strenger
# afgesteld dan de stopifnot hieronder): van de 3001 geprobeerde zaden vanaf
# 20261011 haalden er zeven ze allemaal, en dit is het derde.

set.seed(20262948)

# Cel-opzet: per cel aantal dieren, verwacht aantal onthouden voorwerpen (van
# de veertig), en spreiding. De kleinste cel (oud + dutje) krijgt de grootste
# spreiding.
cellen <- data.frame(
  slaap    = c("wakker", "dutje", "nachtslaap", "wakker", "dutje", "nachtslaap"),
  leeftijd = c("jong",   "jong",  "jong",       "oud",    "oud",   "oud"),
  n        = c(23,       21,      24,           22,       17,      19),
  mu       = c(18,       21,      26,           19,       24,      23),
  sd       = c(4.5,      4.5,     4.5,          4.5,      6,       4.5),
  stringsAsFactors = FALSE
)

olifant_geheugen <- do.call(rbind, lapply(seq_len(nrow(cellen)), function(i) {
  x <- round(rnorm(cellen$n[i], cellen$mu[i], cellen$sd[i]))
  data.frame(onthouden = pmin(pmax(x, 0), 40),      # een telling: 0 tot 40
             leeftijd  = cellen$leeftijd[i],
             slaap     = cellen$slaap[i])
}))
olifant_geheugen$onthouden <- as.integer(olifant_geheugen$onthouden)
olifant_geheugen$leeftijd  <- factor(olifant_geheugen$leeftijd,
                                     levels = c("jong", "oud"))
olifant_geheugen$slaap     <- factor(olifant_geheugen$slaap,
                                     levels = c("wakker", "dutje", "nachtslaap"))

# Snelle controles
cat("--- structuur ---\n"); str(olifant_geheugen)
cat("--- celtellingen ---\n"); print(table(olifant_geheugen$leeftijd, olifant_geheugen$slaap))
cat("--- celgemiddelden ---\n")
print(aggregate(onthouden ~ leeftijd * slaap, data = olifant_geheugen, FUN = mean))

# 2 x 3 ANOVA, Type III.
options(contrasts = c("contr.sum", "contr.poly"))
m <- lm(onthouden ~ leeftijd * slaap, data = olifant_geheugen)
a <- car::Anova(m, type = 3)
cat("--- Anova type III ---\n"); print(a)
cat("--- eta^2 (type 3) ---\n"); print(lsr::etaSquared(m, type = 3))

tk <- TukeyHSD(aov(onthouden ~ slaap, data = olifant_geheugen))$slaap
m1 <- lm(onthouden ~ slaap, data = olifant_geheugen)
ct <- summary(emmeans::contrast(emmeans::emmeans(m1, ~ slaap),
                                list(c(-2, 1, 1) / 2, c(0, -1, 1))))
cm  <- with(olifant_geheugen, tapply(onthouden, list(leeftijd, slaap), mean))
sdc <- with(olifant_geheugen, tapply(onthouden, list(leeftijd, slaap), sd))
nc  <- with(olifant_geheugen, table(leeftijd, slaap))

stopifnot(
  a["slaap", "Pr(>F)"] < .001,
  a["leeftijd", "Pr(>F)"] > .05,
  a["leeftijd:slaap", "Pr(>F)"] < .05,
  abs(cm["jong", "wakker"] - cm["oud", "wakker"]) < 1,
  cm["oud", "dutje"] > cm["jong", "dutje"],
  cm["jong", "nachtslaap"] > cm["oud", "nachtslaap"],
  tk["dutje-wakker", "p adj"] < .05,
  tk["nachtslaap-wakker", "p adj"] < .05,
  tk["nachtslaap-dutje", "p adj"] > .05,
  ct$p.value[1] < .05,
  ct$p.value[2] < .05,
  nc[which(sdc == max(sdc), arr.ind = TRUE)] == min(nc),
  max(nc) / min(nc) < 1.5,
  max(sdc) / min(sdc) < 2,
  min(nc) >= 15
)

save(olifant_geheugen, file = "data/olifant_geheugen.RData")
