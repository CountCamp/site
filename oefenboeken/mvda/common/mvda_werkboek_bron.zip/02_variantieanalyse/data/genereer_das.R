# Genereer dassen_burcht dataset voor het ANOVA-thema, R-practical voorbeeld E5.
# Dier-context: een ecoloog meet bij 78 dassen hoe lang ze gemiddeld per nacht
# foerageren (foerageertijd, in minuten). Twee factoren:
#   - bodem (zand / klei / leem)  — drie niveaus
#   - seizoen (zomer / winter)    — twee niveaus
# Design: 3 x 2 factorial. Hoofdvraag: maakt bodem uit, en is het effect
# anders in zomer dan in winter (interactie)?
#
# Verwacht: significant hoofdeffect bodem, klein hoofdeffect seizoen, en een
# duidelijke interactie (op zandbodem in de zomer kort, in winter juist lang).
#
# Met set.seed(20260504) reproduceerbaar.

set.seed(20260504)

# Per cel zes tot veertien dassen — licht ongebalanceerd, zoals in echte data.
celgroottes <- c(
  "zand-zomer"   = 14,
  "zand-winter"  = 13,
  "klei-zomer"   = 13,
  "klei-winter"  = 13,
  "leem-zomer"   = 12,
  "leem-winter"  = 13
)
N <- sum(celgroottes)   # = 78

bodem    <- factor(rep(c("zand","zand","klei","klei","leem","leem"), celgroottes),
                   levels = c("zand","klei","leem"))
seizoen  <- factor(rep(c("zomer","winter"), times = 3) |> rep(celgroottes),
                   levels = c("zomer","winter"))

# Bovenstaande rep-truc faalt; we bouwen het netjes op:
bodem   <- factor(c(
  rep("zand",  celgroottes[["zand-zomer"]]),
  rep("zand",  celgroottes[["zand-winter"]]),
  rep("klei",  celgroottes[["klei-zomer"]]),
  rep("klei",  celgroottes[["klei-winter"]]),
  rep("leem",  celgroottes[["leem-zomer"]]),
  rep("leem",  celgroottes[["leem-winter"]])
), levels = c("zand","klei","leem"))

seizoen <- factor(c(
  rep("zomer",  celgroottes[["zand-zomer"]]),
  rep("winter", celgroottes[["zand-winter"]]),
  rep("zomer",  celgroottes[["klei-zomer"]]),
  rep("winter", celgroottes[["klei-winter"]]),
  rep("zomer",  celgroottes[["leem-zomer"]]),
  rep("winter", celgroottes[["leem-winter"]])
), levels = c("zomer","winter"))

# Cel-gemiddelden in minuten foerageertijd per nacht.
# Patroon: in winter foerageren dassen langer dan in zomer (hoofdeffect).
# Bodem-effect: zand korter dan klei, leem langst.
# Interactie: op zandbodem is het seizoenseffect klein; op leem is het groot.
cel_means <- c(
  "zand-zomer"   = 95,
  "zand-winter"  = 105,
  "klei-zomer"   = 110,
  "klei-winter"  = 130,
  "leem-zomer"   = 115,
  "leem-winter"  = 155
)

cel_id <- paste(as.character(bodem), as.character(seizoen), sep = "-")
mu_per_dier <- cel_means[cel_id]

foerageertijd <- round(mu_per_dier + rnorm(N, mean = 0, sd = 16), 1)

dassen_burcht <- data.frame(
  foerageertijd = as.numeric(foerageertijd),
  bodem         = bodem,
  seizoen       = seizoen
)

# Snelle controles
cat("--- structuur ---\n"); str(dassen_burcht)
cat("--- celtellingen ---\n"); print(table(dassen_burcht$bodem, dassen_burcht$seizoen))
cat("--- celgemiddelden ---\n"); print(aggregate(foerageertijd ~ bodem * seizoen,
                                                 data = dassen_burcht, FUN = mean))

# 3x2 ANOVA — moet hoofdeffect bodem en seizoen + interactie laten zien.
options(contrasts = c("contr.sum", "contr.poly"))
m <- lm(foerageertijd ~ bodem * seizoen, data = dassen_burcht)
cat("--- Anova type III ---\n"); print(car::Anova(m, type = 3))
cat("--- eta^2 ---\n"); print(lsr::etaSquared(m))

save(dassen_burcht, file = "data/dassen_burcht.RData")
