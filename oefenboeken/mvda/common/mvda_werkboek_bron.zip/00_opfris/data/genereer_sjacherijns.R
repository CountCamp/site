# Genereer de sjacherijns-dataset voor MVDA-thema 0 (Opfris).
#
# Verhaal-frame: negen sjacherijn-diertjes hadden 's morgens geen zin.
# Elk pakt op zijn eigen tempo wat taakjes op. Aan het eind van de dag:
# hoe rustig kunnen ze slapen?
#
# Didactisch ontwerp:
# - N = 9 (kleine, overzichtelijke dataset)
# - X = rondjes (aantal taakjes vandaag aangepakt, 0 tot 8)
#   --> Inclusief het diertje dat ZERO taakjes pakte (das, bleef in hol).
#       Dat geeft een interpreteerbaar intercept: b0 = voorspelde slaap_rust
#       voor een sjacherijn die geen enkel taakje aanpakt.
# - Y = slaap_rust (op schaal 0-100)
#
# Gemiddelden / sommen-van-kwadraten — opzettelijk genoeg-rond:
#   mean(X) = 4     mean(Y) = 60
#   SS_X    = 60    SS_Y    = 3000   SS_XY = 420
#   b1 = SS_XY / SS_X = 420 / 60 = 7
#   b0 = mean(Y) - b1 * mean(X) = 60 - 7 * 4 = 32
#   R^2 = 0.98 (bijna perfecte lineaire fit — bedoeld voor "regressielijn met het oog")
#
# F = t^2 = 343 (zelfde als bij vorige versie van de dataset, want lineaire schaal-shift)

sjacherijns <- data.frame(
  sjacherijn  = c("das", "muis", "mus", "egel", "kikker",
                  "konijn", "merel", "veldmuis", "bunzing"),
  taakje      = c("bleef in zijn hol",
                  "nestje schoonmaken",
                  "kindertjes voeren",
                  "slakken-route afleggen",
                  "vliegen vangen",
                  "gras knabbelen",
                  "wormen pluizen",
                  "zaadjes verzamelen",
                  "sluiproutes verkennen"),
  rondjes     = 0:8,
  slaap_rust  = c(30, 40, 50, 50, 60, 70, 70, 80, 90)
)

save(sjacherijns, file = "sjacherijns.RData")
