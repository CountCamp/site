# Genereer otter_huishouden dataset voor het ANCOVA-thema, opdracht E5.
#
# Dier-context: een otter en zijn partner houden hun huishouden bij — hoe
# tevreden zijn ze ermee? Hangt af van (a) de dagstijl van de partner
# (dagslaper / nachtbraker / wisselend) en (b) hoeveel uur ze samen
# doorbrengen per week. Eén factor (partner_stijl, 3 niveaus), één continue
# covariaat (gedeelde_tijd, uren), en een afhankelijke (huishoudtevredenheid,
# score 0-100).
#
# Doelen:
#   - factor partner_stijl:        matig significant na correctie (p < .05),
#                                  eta^2_p ~ .10
#   - covariaat gedeelde_tijd:     sterk significant, eta^2_p ~ .20-.35
#                                  (positief: meer gedeelde tijd = tevredener)
#   - parallellism (interactie):   niet significant (p > .15)
#   - lichte covariaat-verschillen tussen groepen
#   - N tussen 75 en 85, ongebalanceerd
#
# Plagend: dagslaper matig (mist de otter overdag), nachtbraker iets
# hoger als veel gedeelde tijd, wisselend onvoorspelbaar.
#
# Reproduceerbaar via set.seed(20260507).
#
# Geen niveau heeft een streepje in zijn naam, en dat is met opzet: de functie
# emmeans_test() uit het pakket rstatix, waarmee dit oefenboek na een ANCOVA
# paarsgewijs vergelijkt, knipt de namen van een paar op elk streepje. Een
# niveau als "overdag-ruster" levert in de uitvoer van emmeans_test() twee
# regels op die allebei "overdag" tegen "ruster" heten. Daarom heet het eerste
# niveau "dagslaper".

set.seed(20260507)

n_per <- c(`dagslaper` = 26, nachtbraker = 27, wisselend = 25)
N     <- sum(n_per)   # 78

partner_stijl <- factor(c(
  rep("dagslaper", n_per[["dagslaper"]]),
  rep("nachtbraker",    n_per[["nachtbraker"]]),
  rep("wisselend",      n_per[["wisselend"]])
), levels = c("dagslaper", "nachtbraker", "wisselend"))

# Gedeelde tijd (uren samen per week), licht verschillend per stijl.
#   dagslaper: gemiddeld 18 (ze rusten overdag, otter vist overdag)
#   nachtbraker:    gemiddeld 24 (ze pakken de nacht samen)
#   wisselend:      gemiddeld 22
gedeelde_tijd <- numeric(N)
gedeelde_tijd[partner_stijl == "dagslaper"] <- round(rnorm(n_per[["dagslaper"]], mean = 18, sd = 5), 1)
gedeelde_tijd[partner_stijl == "nachtbraker"]    <- round(rnorm(n_per[["nachtbraker"]],    mean = 24, sd = 6), 1)
gedeelde_tijd[partner_stijl == "wisselend"]      <- round(rnorm(n_per[["wisselend"]],      mean = 22, sd = 6), 1)
gedeelde_tijd <- pmax(gedeelde_tijd, 4)

# Huishoudtevredenheid: positief covariaat-effect (meer samen = tevredener),
# plus stijl-shift.
#   dagslaper:  -5   (matig, mist de otter overdag)
#   nachtbraker:     +6   (iets hoger, vooral met veel gedeelde tijd)
#   wisselend:        0   (gemiddeld neutraal, met grote spreiding)
stijl_shift <- c(`dagslaper` = -5, nachtbraker = 6, wisselend = 0)
b_w         <- 1.4

mu <- 40 + b_w * gedeelde_tijd + stijl_shift[as.character(partner_stijl)]

# Wisselend krijgt extra ruis (onvoorspelbaar).
sd_per_obs <- ifelse(partner_stijl == "wisselend", 11, 7)

set.seed(909)
huishoudtevredenheid <- round(mu + rnorm(N, mean = 0, sd = sd_per_obs))
huishoudtevredenheid <- pmin(pmax(huishoudtevredenheid, 0L), 100L)

otter_huishouden <- data.frame(
  huishoudtevredenheid = as.integer(huishoudtevredenheid),
  gedeelde_tijd        = as.numeric(gedeelde_tijd),
  partner_stijl        = partner_stijl
)

cat("--- structuur ---\n"); str(otter_huishouden)
cat("--- celtellingen ---\n"); print(table(otter_huishouden$partner_stijl))
cat("--- covariaat-means ---\n")
print(aggregate(gedeelde_tijd ~ partner_stijl, data = otter_huishouden, FUN = mean))
cat("--- raw Y-means ---\n")
print(aggregate(huishoudtevredenheid ~ partner_stijl, data = otter_huishouden, FUN = mean))

# Factor eerst, covariaat daarna.
options(contrasts = c("contr.sum", "contr.poly"))
m <- lm(huishoudtevredenheid ~ partner_stijl + gedeelde_tijd, data = otter_huishouden)
cat("--- ANCOVA Type III ---\n"); print(car::Anova(m, type = 3))
cat("--- partial eta^2 ---\n"); print(lsr::etaSquared(m))
cat("--- coefficienten ---\n"); print(coef(m))

m_par <- lm(huishoudtevredenheid ~ partner_stijl * gedeelde_tijd, data = otter_huishouden)
cat("--- Parallellism-check ---\n"); print(car::Anova(m_par, type = 3))

suppressPackageStartupMessages(library(emmeans))
cat("--- EMM (adjusted) ---\n"); print(emmeans(m, ~ partner_stijl))
cat("--- pairs (Bonferroni) ---\n")
print(pairs(emmeans(m, ~ partner_stijl), adjust = "bonferroni"))

save(otter_huishouden, file = "data/otter_huishouden.RData")
