# Genereer bever_tevredenheid dataset voor het ANCOVA-thema (3.1, 3.2).
#
# Dier-context: een bever bouwt zijn dam, en vraagt zich na een tijdje af
# hoe tevreden hij eigenlijk is met het resultaat. Hangt blijkbaar af van
# (a) zijn werkstijl (perfectionist / pragmaticus / impulsief) en
# (b) hoeveel familieleden meegeholpen hebben tijdens het bouwen.
# Eén factor (bouwwoede, 3 niveaus), één continue covariaat
# (meedoende_familie, aantal familieleden), en één afhankelijke
# (damtevredenheid, score 0-100).
#
# Plagend (Tellegen + brutaal-droog VPRO):
#   - Perfectionisten:  zelden tevreden, ook met hulp
#   - Pragmatici:       meestal tevreden, vooral met hulp
#   - Impulsieven:      extreem variabel, een paar zijn hoog tevreden,
#                       anderen baal-niveau
#
# Doelen voor de kalibratie:
#   - hoofdeffect bouwwoede:               significant, eta^2_p ~ .15-.20
#   - covariaat-effect (meedoende_familie): sterk significant,
#                                            b_w ~ 2-4 per familielid
#   - parallellism (interactie):            NIET significant (p > .15)
#   - perfectionisten kregen minder hulp:   bias-correctie zichtbaar
#                                            via verschillende C-bars
#   - ongeveer N = 90, ongebalanceerd
#
# Reproduceerbaar via set.seed(20260506).

set.seed(20260506)

# Cel-aantallen per werkstijl; licht ongebalanceerd.
n_per <- c(perfectionist = 30, pragmaticus = 32, impulsief = 28)
N     <- sum(n_per)   # 90

bouwwoede <- factor(c(
  rep("perfectionist", n_per[["perfectionist"]]),
  rep("pragmaticus",   n_per[["pragmaticus"]]),
  rep("impulsief",     n_per[["impulsief"]])
), levels = c("perfectionist", "pragmaticus", "impulsief"))

# Meedoende familie (aantal familieleden, 0-15). Perfectionisten krijgen
# systematisch minder hulp (zij willen het zelf doen / familie haakt af),
# pragmatici en impulsieven trekken meer familie aan.
#   perfectionist: gemiddeld  4.5
#   pragmaticus:   gemiddeld  7.8
#   impulsief:     gemiddeld  7.2
meedoende_familie <- numeric(N)
meedoende_familie[bouwwoede == "perfectionist"] <- round(rnorm(n_per[["perfectionist"]], mean = 4.5, sd = 2.4))
meedoende_familie[bouwwoede == "pragmaticus"]   <- round(rnorm(n_per[["pragmaticus"]],   mean = 7.8, sd = 2.6))
meedoende_familie[bouwwoede == "impulsief"]     <- round(rnorm(n_per[["impulsief"]],     mean = 7.2, sd = 2.8))
meedoende_familie <- pmin(pmax(meedoende_familie, 0L), 15L)

# Damtevredenheid: lineair in covariaat (gemeenschappelijke slope ~ 3.0),
# plus werkstijl-shift, plus ruis. Impulsieven krijgen extra ruis (extreem
# variabel: een paar erg hoog, anderen baal-niveau).
#   shift perfectionist: -5  (zelden tevreden, ook met hulp)
#   shift pragmaticus:   +4  (meestal tevreden, vooral met hulp)
#   shift impulsief:      0  (gemiddeld neutraal, maar grote spreiding)
stijl_shift <- c(perfectionist = -5, pragmaticus = 4, impulsief = 0)
b_w         <- 3.0

mu <- 50 + b_w * meedoende_familie + stijl_shift[as.character(bouwwoede)]

# Heteroscedastiek: impulsieven krijgen bredere ruis (sd = 16), de andere
# twee normaal (sd = 9). Levert het 'extreem variabel' effect.
sd_per_obs <- ifelse(bouwwoede == "impulsief", 16, 9)

set.seed(404)
damtevredenheid <- round(mu + rnorm(N, mean = 0, sd = sd_per_obs))
damtevredenheid <- pmin(pmax(damtevredenheid, 0L), 100L)

# Voeg een borderline outlier toe — een impulsieve bever die ondanks
# weinig familie-hulp toch heel tevreden is. Zichtbaar in Cook's distance.
i_out <- which(bouwwoede == "impulsief" & meedoende_familie < 4)[1]
if (is.na(i_out)) i_out <- which(bouwwoede == "impulsief")[which.min(meedoende_familie[bouwwoede == "impulsief"])]
damtevredenheid[i_out] <- 95L

bever_tevredenheid <- data.frame(
  damtevredenheid   = as.integer(damtevredenheid),
  meedoende_familie = as.integer(meedoende_familie),
  bouwwoede         = bouwwoede
)

# Snelle controles
cat("--- structuur ---\n"); str(bever_tevredenheid)
cat("--- celtellingen ---\n"); print(table(bever_tevredenheid$bouwwoede))
cat("--- covariaat-means per groep ---\n")
print(aggregate(meedoende_familie ~ bouwwoede, data = bever_tevredenheid, FUN = mean))
cat("--- raw Y-means per groep ---\n")
print(aggregate(damtevredenheid ~ bouwwoede, data = bever_tevredenheid, FUN = mean))

# ANCOVA - type III. LEIDEN-CONVENTIE: factor eerst, covariaat daarna.
options(contrasts = c("contr.sum", "contr.poly"))
m_ancova   <- lm(damtevredenheid ~ bouwwoede + meedoende_familie, data = bever_tevredenheid)
cat("--- ANCOVA Type III ---\n");  print(car::Anova(m_ancova, type = 3))
cat("--- partial eta^2 ANCOVA ---\n"); print(lsr::etaSquared(m_ancova))
cat("--- coefficienten (b_w te zien bij meedoende_familie) ---\n"); print(coef(m_ancova))

# Parallellism-check.
m_par <- lm(damtevredenheid ~ bouwwoede * meedoende_familie, data = bever_tevredenheid)
cat("--- Parallellism-check (interactie) Type III ---\n"); print(car::Anova(m_par, type = 3))
cat("--- partial eta^2 met interactie ---\n"); print(lsr::etaSquared(m_par))

# Vergelijking ANOVA versus ANCOVA (foutreductie illustreren).
m_anova <- lm(damtevredenheid ~ bouwwoede, data = bever_tevredenheid)
cat("--- ANOVA zonder covariaat ---\n"); print(car::Anova(m_anova, type = 3))
cat("--- partial eta^2 ANOVA-only ---\n"); print(lsr::etaSquared(m_anova))

# Adjusted means.
suppressPackageStartupMessages(library(emmeans))
cat("--- EMM (adjusted means) per bouwwoede ---\n")
print(emmeans(m_ancova, ~ bouwwoede))

# Cook's distance check.
cd <- cooks.distance(m_ancova)
cat("--- max Cook's distance ---\n"); print(round(max(cd), 3))

save(bever_tevredenheid, file = "data/bever_tevredenheid.RData")
