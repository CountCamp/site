#!/usr/bin/env python3
r"""Zet losse Griekse letters in de wiskunde rechtop. Draait ná de render.

    python3 _grieks_rechtop.py            # bewerkt _site/
    python3 _grieks_rechtop.py PAD        # of een losse map/bladzijde
    python3 _grieks_rechtop.py --toets    # verandert niets, meldt alleen de telling

Staat als `post-render` in `_quarto.yml`, dus hij gaat bij elke render vanzelf af.

WAAROM DIT BESTAAT
------------------
APA zet Latijnse symbolen cursief en Griekse letters **rechtop**: χ²(51) = 38.36,
α = .87. De browser doet het omgekeerde. MathML Core geeft elke `<mi>` met één
teken erin `text-transform: math-auto`, en dat maakt er een cursieve letter van --
Latijn én Grieks. Gemeten op de render van 27-9-2026: 276 losse kleine Griekse
letters cursief, 15 rechtop.

Onder MathJax was dit niet te repareren: `\mathrm{\chi}` deed daar niets aan een
Griekse letter. Sinds `html-math-method: mathml` (besluit 27-9-2026) kan het wel.

WAAROM EEN STAP NÁ DE RENDER EN NIET IN DE BRON
-----------------------------------------------
Het kán in de bron: `$\mathrm{\chi}^2(51) = 38.36$` levert
`<mi mathvariant="normal">χ</mi>`. Maar dat zijn 253 plekken in vijf thema's, en
elke volgende schrijver moet het onthouden. Als stap ná de render is het een
mechanisme dat vanzelf afgaat, ook voor thema 6 en 7 als die straks uit
`drafts:` komen (samen 71 kleine Griekse letters).

DE HOOFDLETTERS STAAN HIER BUITEN, EN DAT IS GEMETEN
----------------------------------------------------
Pandoc geeft hoofdletter-Grieks zelf al `mathvariant="normal"`: `\Lambda` wordt
`<mi mathvariant="normal">Λ</mi>`. Dat is precies waarom de render 15 rechtopse
letters had -- en het zijn exact de 15 hoofdletters in de bron (Δ 8, Φ 5, Λ 2).
Deze stap raakt ze niet aan, en dat hoort zo: een `<mi>` die al een
`mathvariant` draagt wordt overgeslagen. Daardoor is de stap ook idempotent --
twee keer draaien verandert niets.

HOE JE EEN LETTER TÓCH CURSIEF HOUDT -- EN WANNEER DAT MOET
-----------------------------------------------------------
Rechtop is hier de default omdat het in dit werkboek de grote meerderheid is,
maar het is NIET de regel voor alles. De TAALGIDS kent drie registers (besluit
Ben, 14-8-2026, r177-181), en in register 2 -- een échte formule -- is kleine
Griek **cursief** en alleen hoofdletter-Griek rechtop:

    register 1  uitleg      "de betrouwbaarheid (α)"          rechtop
    register 2  formule     se_m = SD · √(1 − α)              CURSIEF
    register 3  rapportage  α = .87, χ²(51) = 38.36           rechtop

De gids waarschuwt zelf voor precies deze fout in de andere richting: tot
13-8-2026 noemde hij χ², β en η² **onvoorwaardelijk cursief**, en dat is
teruggedraaid. Onvoorwaardelijk rechtop is dezelfde fout in de spiegel.

Schrijf in een formule daarom `\mathit{\alpha}`. Dat wordt geen attribuut maar
een ánder teken: pandoc levert U+1D6FC MATHEMATICAL ITALIC SMALL ALPHA (𝛼), en
dat valt buiten het Griekse blok U+0370-U+03FF. Deze stap ziet zo'n letter dus
niet, en hoeft er ook niets voor uit te zonderen. Hij is bovendien cursief in
élke browser, los van wat die met `mathvariant` doet -- en dat is hier niet
theoretisch: Chrome honoreert **alleen** `mathvariant="normal"` en negeert
`italic`, `bold` en de rest (gemeten 27-9-2026, `_BESLUITEN.md` punt D).

`\upalpha` werkt níét -- pandoc mapt dat terug op een gewone cursieve `<mi>`.
Gemeten in `_griekmeting/`.

Afloopcodes volgens huisafspraak: 0 schoon, 1 er is iets gevonden (alleen bij
`--toets`), 3 kon niet kijken. Nul bladzijden is code 3 en niet 0 -- niets
gevonden is niet hetzelfde als niet gekeken.
"""

from __future__ import annotations

import os
import pathlib
import re
import sys

WORTEL = pathlib.Path(__file__).resolve().parent

# Het Griekse en Koptische blok. Hier staan de tekens die pandoc levert voor een
# kale `\alpha`. De cursieve tegenhangers die `\mathit{}` oplevert wonen in
# U+1D6A8-U+1D7CB (Mathematical Alphanumeric Symbols) en vallen er dus buiten --
# dat is precies de ontsnappingsroute die de kopregels hierboven beschrijven.
GRIEKS_VAN, GRIEKS_TOT = "Ͱ", "Ͽ"

# Alleen de kleine letters hoeven iets. De hoofdletters krijgen hun
# `mathvariant="normal"` al van pandoc en worden hieronder overgeslagen omdat ze
# al een attribuut hebben -- niet omdat we ze op naam uitzonderen. Die twee wegen
# geven vandaag hetzelfde antwoord, en als pandoc dat ooit verandert wil ik dat
# de toets hieronder het merkt in plaats van dat een naamlijst het verbergt.
MI = re.compile(r"<mi(?![A-Za-z])([^>]*)>([^<]*)</mi>")
HEEFT_VARIANT = re.compile(r"\bmathvariant\s*=")


def is_los_grieks(inner: str) -> bool:
    """Eén enkel teken uit het Griekse blok, en niets anders."""
    return len(inner) == 1 and GRIEKS_VAN <= inner <= GRIEKS_TOT


def bewerk(tekst: str) -> tuple[str, int, int]:
    """Geeft (nieuwe tekst, aantal rechtop gezet, aantal al goed)."""
    gezet = overgeslagen = 0

    def vervang(m: re.Match[str]) -> str:
        nonlocal gezet, overgeslagen
        attrs, inner = m.group(1), m.group(2)
        if not is_los_grieks(inner):
            return m.group(0)
        if HEEFT_VARIANT.search(attrs):
            overgeslagen += 1
            return m.group(0)
        gezet += 1
        return f'<mi{attrs} mathvariant="normal">{inner}</mi>'

    return MI.sub(vervang, tekst), gezet, overgeslagen


def bladzijden(argv: list[str]) -> list[pathlib.Path]:
    paden = [a for a in argv if not a.startswith("-")]
    if paden:
        p = pathlib.Path(paden[0])
        return [p] if p.is_file() else sorted(p.rglob("*.html"))
    # Quarto geeft de uitvoermap mee als hij ons als post-render start; buiten
    # een render bestaat die variabele niet en valt hij terug op _site.
    uit = os.environ.get("QUARTO_PROJECT_OUTPUT_DIR")
    map_ = (WORTEL / uit) if uit else (WORTEL / "_site")
    return sorted(map_.rglob("*.html"))


def main() -> int:
    alleen_toetsen = "--toets" in sys.argv
    paginas = bladzijden(sys.argv[1:])
    if not paginas:
        print("grieks-rechtop: 0 bladzijden gevonden -- ER IS NIET GEKEKEN", file=sys.stderr)
        return 3

    totaal_gezet = totaal_al_goed = 0
    geraakt: list[tuple[str, int]] = []
    for p in paginas:
        tekst = p.read_text(encoding="utf-8")
        nieuw, gezet, al_goed = bewerk(tekst)
        totaal_gezet += gezet
        totaal_al_goed += al_goed
        if gezet:
            try:
                naam = str(p.relative_to(WORTEL))
            except ValueError:
                naam = str(p)
            geraakt.append((naam, gezet))
            if not alleen_toetsen:
                p.write_text(nieuw, encoding="utf-8")

    woord = "zou rechtop gaan" if alleen_toetsen else "rechtop gezet"
    print(f"grieks-rechtop: {len(paginas)} bladzijden, {totaal_gezet} losse Griekse "
          f"letter(s) {woord}, {totaal_al_goed} stonden al rechtop")
    for naam, n in geraakt:
        print(f"    {naam}: {n}")

    if alleen_toetsen and totaal_gezet:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
