#!/usr/bin/env python3
r"""Griekse letters in de wiskunde: rechtop als ze benoemen of een waarde krijgen,
cursief als ze in een formule meerekenen. Draait ná de render, over _site/.

    python3 grieks_rechtop.py            # bewerkt de gebouwde site
    python3 grieks_rechtop.py PAD        # een andere map, of één bladzijde
    python3 grieks_rechtop.py --toets    # verandert niets; afloop 1 als er iets zou veranderen
    python3 grieks_rechtop.py --toon     # verandert niets; toont elke formule die cursief blijft

Zonder PAD kijkt hij in de map die Quarto meegeeft (QUARTO_PROJECT_OUTPUT_DIR),
en anders in `_site/` van het boek waar hij in staat: de map erboven als hij in
`_controles/` staat, en anders zijn eigen map.

DE REGEL: DRIE REGISTERS
------------------------
Een Griekse letter doet niet overal hetzelfde, en zijn zetting volgt wat hij doet:

    uitleg       "de betrouwbaarheid (α)"           benoemt         rechtop
    rapportage   χ²(4, N = 440) = 23.24, α = .87    krijgt waarde   rechtop (APA)
    berekening   X = μ + zσ                         rekent mee      klein: cursief
                                                                    hoofdletter: rechtop

De grens loopt niet door de plek (lopende tekst, losse formuleregel, tabel) maar
door het werk van de letter. Staat er in hetzelfde stuk wiskunde nog een ánder
symbool, hoe klein en hoe inline ook, dan rekent hij mee en blijft hij cursief.
Staan er alleen getallen naast hem (μ = 100, α = .05/3 = .017), dan krijgt hij
een waarde en gaat hij rechtop. Een hoofdletter (Λ, Φ, Σ) staat altijd rechtop.

HOE HIJ "HETZELFDE STUK" AFBAKENT
---------------------------------
Per `<math>`-element, in vier stappen.

  1. Een symbool is een letter met alles wat eraan vastzit. In σ_x̄ is de x̄ het
     subscript van de σ ("de sigma van wát?") en geen tweede symbool, en in η²_p
     is de p dat ook niet. Een Δ direct vóór een symbool hoort erbij: Δχ² is één
     symbool.
  2. Een komma, puntkomma of dubbele punt knipt de wiskunde in stukken, en een
     ruime spatie (`\quad`) en een nieuwe regel in een uitlijning doen dat ook.
     Zo zijn `\mu = 100, \sigma = 15` twee stukken, staat de N in
     χ²(4, N = 440) in een ander stuk dan de χ, en staat de H₀ in
     `H_0: \mu = 100` los van de μ. Een komma tussen twee getallen is een
     decimaalkomma en knipt niet.
  3. Een ánder symbool is een letter: Latijn of Grieks, ook vet of cursief uit
     `\mathit{}`. Geen symbool zijn getallen, tekens, tekst uit `\text{}`, een
     functienaam van meer letters (log, exp) en een losse Latijnse letter die de
     bron al rechtop zette (`\mathrm{d}`, een label).
  4. Een Griekse letter in het sub- of superscript van een ander symbool (de α in
     z_{α/2}) volgt het symbool waar hij aan vastzit.

Een losse formuleregel (`$$ ... $$`) volgt dezelfde regel als wiskunde in de
lopende tekst. Een rij getallen ingevuld in een losse regel is nog steeds een
letter die een waarde krijgt.

TWEE PLEKKEN WAAR EEN LETTER NAAST EEN ANDER SYMBOOL TOCH BENOEMT
---------------------------------------------------------------
Hier staat er wel een ánder symbool naast de Griekse letter, en toch rekent hij
niet: hij benoemt. Dan gaat hij rechtop.

  * De beslisregel. Een p vergeleken met een Griekse letter: p ≤ α, p < α/2,
    p > α (.05), p_(1) < α_1, en de grens "ook bij p = α". In het stuk wiskunde
    staat een p (met wat eraan vastzit) direct naast een vergelijkingsteken
    (<, >, ≤, ≥ of =), minstens één Griekse letter, en verder geen ander
    symbool, alleen getallen en tekens. Zo blijft α_2 = α/(k − 1) een formule
    (daar rekent de k mee), en α = .05/p ook: daar wordt door p gedeeld, en
    staat hij niet naast het =-teken. P(X̄ > x̄_c | μ_0) = α valt er ook buiten:
    dat is een hoofdletter P met een kans erin, geen p.
  * De hypothese. Wat na H₀, H₁ of Hₐ en een dubbele punt komt, is een uitspraak
    over de populatie, en elke Griekse letter erin gaat rechtop: H₀: μ₁ = μ₂ ziet
    er dan net zo uit als H₀: μ_d = 0. Ook een verschil of een contrast:
    H₀: μ₁ − μ₂ = 0, Hₐ: (μ₂ + μ₃ + μ₄)/3 − μ₁ > 0. Drie vormen:
      - in één stuk wiskunde: `$H_0: \mu_1 = \mu_2$`. Het stuk ná de dubbele
        punt is de hypothese, tot de volgende knip;
      - in twee: `$H_0$: $\mu_1 = \mu_2$`. Een <math> met alleen het etiket,
        daarna niets dan een dubbele punt (geen tag, geen woord), en dan de
        <math> die de hypothese is, als geheel;
      - in een tabelrij waarvan de eerste cel alleen het etiket is: elke <math>
        in de andere cellen van die rij.
    Het etiket is een H met als subscript precies 0, 1, a of A. "Onder H₀",
    "H₀ waar is: …" en een H₀ in een opsomming zijn geen etiket met een
    hypothese erachter; die vallen erbuiten.

Wat niet onder deze twee valt, blijft bij de hoofdregel. Ook een kritieke
grens als z ≥ z_{α/2}: daar zit de α in het subscript van de z, en volgt hij de
z.

WAT HIJ AANRAAKT
----------------
Alleen een `<mi>` met precies één Grieks teken en nog geen `mathvariant`. Gaat
die rechtop, dan krijgt hij `mathvariant="normal"`. Blijft hij cursief, dan laat
de stap hem zoals hij is, en tekent de browser hem cursief.

  * Latijn blijft wat het was: <mi>x</mi>, <mi>z</mi> en <mi>p</mi> horen cursief.
  * Alleen dit knooppunt, nooit het `<msub>` of `<mrow>` eromheen. In σ_x is de x
    een variabele en blijft hij cursief.
  * Grieks buiten `<mi>` blijft onaangeroerd. Een Grieks teken in een URL-anker
    (`#van-z-naar-t-σ-kennen-we-nooit`) of in `<mtext>` is geen wiskunde. Een
    reparatie die op tekens jaagt in plaats van op elementen, breekt zo'n link
    zonder dat de render erop faalt.
  * Wat de bron al vastlegde, blijft staan. `\mathrm{\alpha}` levert
    `mathvariant="normal"` (rechtop), en `\mathit{\alpha}` levert een ánder
    teken, U+1D6FC (𝛼), dat buiten het Griekse blok valt. Beide slaat de stap
    over. Zo kan een schrijver de regel in één formule overrulen, en blijft de
    stap herhaalbaar: twee keer draaien verandert niets.
  * Hoofdletters zet Pandoc zelf al rechtop (`\Lambda` wordt
    `<mi mathvariant="normal">Λ</mi>`). Komt er toch een kale binnen, dan gaat
    die ook rechtop.

WAAROM ZO, EN NIET IN CSS OF IN DE BRON
---------------------------------------
De browser tekent de wiskunde zelf (MathML). MathML Core geeft elke `<mi>` met
precies één teken `text-transform: math-auto`, en dat vervangt de letter door
zijn cursieve wiskundige tegenhanger: `<mi>α</mi>` wordt op het scherm 𝛼. Voor
Latijn is dat goed, voor een Griekse letter die benoemt niet. CSS kan niet op de
inhoud van een element selecteren: er is geen selector voor "een `<mi>` met een
Griekse letter erin", en `math mi { text-transform: none }` zou ook de x en de z
rechtop zetten. Het verschil zit in het teken, dus moet de ingreep bij het teken.

Drie kandidaten zijn in Chrome naast elkaar gelegd, met een breedtemeting:

    $\upalpha$           -> <mi>α</mi>, ongewijzigd                 WERKT NIET
    $\mathit{df}$        -> <mi>𝑑</mi><mi>𝑓</mi>, nog steeds twee   WERKT NIET
    $\mathrm{\alpha}$    -> <mi mathvariant="normal">α</mi>         WERKT

Wie dit nameet: meet de getekende BREEDTE of lees het attribuut, nooit
`mi.textContent`. `text-transform` raakt de tekst in de DOM niet; daar staat
altijd "α", ook als de browser 𝛼 tekent. Een meting die het verschil niet kán
zien, geeft hetzelfde terug als een meting die geen verschil vindt. Chrome
honoreert van `mathvariant` alleen de waarde "normal"; "italic" doet daar niets.
Daarom zet deze stap nooit iets cursief: cursief is wat er al staat.

In de bron (`.qmd`) is van dit alles niets te zien. Een controle op de bron kan
het dus niet vinden; deze stap kijkt in de gebouwde bladzijden.

WELKE TEKENS GRIEKS ZIJN, REKENT HIJ UIT
----------------------------------------
Niet opgesomd. Een getypte lijst mist ς (eind-sigma) en ϑ, ϕ en ϵ, wat \vartheta,
\varphi en \varepsilon opleveren. Dus: unicodedata noemt het teken, en de eis is
een LETTER met "GREEK" in zijn naam. ʹ (GREEK NUMERAL SIGN) is een leesteken en
valt erbuiten. Klein is wat unicodedata kleine letter noemt (categorie Ll).

ÉÉN TEKST OP DRIE PLEKKEN
-------------------------
Het origineel staat in het Oefenboek OZP 1, als `_controles/grieks_rechtop.py`.
Het TS-boek en OZP 2 voeren dat bestand zelf uit. De Oefenboeken Psychometrie en
MVDA hebben een kopie, `_grieks_rechtop.py`, die byte voor byte gelijk is: hun
bladzijden worden ook gebouwd waar OZP 1 er niet naast staat (in de bron-ZIP van
MVDA, in een proefmap). Een kopie zoekt bij elke run het origineel boven zich
op. Vindt hij het en wijkt hij af, dan zakt hij en noemt hij het `cp`-commando
dat het herstelt. Vindt hij het niet, dan zegt hij dat hij niet vergeleken is.

Afloopcodes: 0 schoon; 1 er is iets mis (of, met --toets, er zou iets
veranderen); 3 kon niet kijken (geen bladzijden, of wiskunde die hij niet kan
lezen).

Getoetst door `_controles/tests/grieks_rechtop_test.sh` in het Oefenboek OZP 1,
mét mutatieproeven: die maken de stap opzettelijk stuk en eisen dat hij dán zakt.
"""

from __future__ import annotations

import html as htmlmod
import os
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

MATH = re.compile(r"<math\b[^>]*>.*?</math>", re.S)
MI = re.compile(r"<mi(?![A-Za-z])(?P<attr>[^>]*)>(?P<tekst>[^<]*)</mi>")
HEEFT_VARIANT = re.compile(r"\bmathvariant\s*=")
RECHTOP = ' mathvariant="normal"'

# Waar het origineel staat, vanaf de wortel van de repo. Een kopie zoekt dit pad
# boven zich op (zie vergelijk_met_origineel).
ORIGINEEL = ("uni_leiden", "pedagogiek", "ozp1_werkboek", "2526_werkboek",
             "_controles", "grieks_rechtop.py")

KNIPTEKENS = {",", ";", ":"}          # knippen buiten haakjes
PIJLEN = {"→", "⇒", "⟶", "⟹"}         # knippen overal: een rij stappen, geen algebra
OPEN, DICHT = set("([{⟨"), set(")]}⟩")
WAARDE = {"=", "≈"}
# Het teken van een beslisregel. Ook =: "verwerp H₀, ook bij p = α" is de grens
# van dezelfde regel.
VERGELIJK = {"<", ">", "≤", "≥", "⩽", "⩾", "="}
H_ONDERSCHRIFT = {"0", "1", "a", "A"}       # H₀, H₁, Hₐ: het etiket van een hypothese
TR = re.compile(r"<tr\b[^>]*>.*?</tr>", re.S)
CEL = re.compile(r"<(t[dh])\b[^>]*>(?P<inhoud>.*?)</\1>", re.S)
SCRIPTS = {"msub", "msup", "msubsup", "mover", "munder", "munderover", "mmultiscripts"}
XML_EIGEN = {"amp", "lt", "gt", "quot", "apos"}


class Onleesbaar(Exception):
    """Wiskunde die de stap niet kan indelen. Liever stoppen dan gokken."""


# ---------------------------------------------------------------- tekens

def is_griekse_letter(teken: str) -> bool:
    """Eén teken, en het is een Griekse LETTER: uitgerekend, niet opgesomd."""
    if len(teken) != 1 or unicodedata.category(teken) not in ("Lu", "Ll", "Lt", "Lm", "Lo"):
        return False
    try:
        return unicodedata.name(teken).startswith("GREEK")
    except ValueError:            # naamloos teken
        return False


def is_kleine_griek(teken: str) -> bool:
    return is_griekse_letter(teken) and unicodedata.category(teken) == "Ll"


def is_enkel_grieks(ruw: str) -> bool:
    """Draagt deze <mi> precies één Griekse letter, zoals de BROWSER hem leest?

    Pandoc schrijft `α` als los teken, maar stond er `&#945;`, dan is dat voor de
    browser óók één teken, en dan gaat math-auto er net zo hard op af. Een stap
    die de tekst letterlijk telt, ziet dan zes tekens, doet niets, en meldt bij
    de zelfcontrole ook niets. Vandaar `unescape` vóór het tellen.
    """
    return is_griekse_letter(htmlmod.unescape(ruw))


# ---------------------------------------------------------------- de wiskunde lezen

def naam(el: ET.Element) -> str:
    return el.tag.rsplit("}", 1)[-1]


def lees_math(stuk: str) -> ET.Element:
    """Eén <math>-element als boom. HTML-entiteiten die XML niet kent (&nbsp;)
    worden eerst tekens; de vijf van XML zelf blijven staan."""
    schoon = re.sub(r"&([A-Za-z][A-Za-z0-9]*);",
                    lambda m: m.group(0) if m.group(1) in XML_EIGEN
                    else htmlmod.unescape(m.group(0)), stuk)
    try:
        return ET.fromstring(schoon)
    except ET.ParseError as e:
        raise Onleesbaar(f"geen geldige MathML ({e})") from None


def is_symbool(mi: ET.Element) -> bool:
    """Telt deze <mi> als een ánder symbool naast een Griekse letter? (stap 3)"""
    t = (mi.text or "").strip()
    if not t or not all(ch.isalpha() for ch in t):
        return False                  # een minteken, ∞, een accent
    variant = mi.get("mathvariant")
    if len(t) == 1:
        try:
            latijn = unicodedata.name(t).startswith("LATIN")
        except ValueError:
            latijn = False
        return not (latijn and variant == "normal")      # \mathrm{d}: een label
    if variant in (None, "normal") and t.isascii():
        return False                  # log, exp, max: een functienaam
    return True                       # \mathit{SD}, \mathbf{B}: een grootheid


class Symbool:
    """Een letter met alles wat eraan vastzit (stap 1)."""
    __slots__ = ("knopen", "telt", "delta", "h_etiket")

    def __init__(self, knopen: list[ET.Element], telt: bool, delta: bool,
                 h_etiket: bool = False) -> None:
        self.knopen = knopen          # alle <mi> van dit symbool, de basis eerst
        self.telt = telt              # telt als ánder symbool voor een Griekse letter
        self.delta = delta            # een Δ die zich aan het volgende symbool hecht
        self.h_etiket = h_etiket      # H₀, H₁ of Hₐ: het etiket van een hypothese

    def letter(self) -> str:
        """De basisletter, zoals hij gelezen wordt: 𝑝 uit \\mathit{p} is ook p."""
        return unicodedata.normalize("NFKC", (self.knopen[0].text or "").strip())


def enkel_mi(el: ET.Element) -> ET.Element | None:
    """De <mi> die deze basis is, ook als hij in een <mrow> van één kind zit."""
    while naam(el) == "mrow" and len(el) == 1:
        el = el[0]
    return el if naam(el) == "mi" else None


def is_h_etiket(soort: str, basis: ET.Element, rest: list[ET.Element]) -> bool:
    """H₀, H₁, Hₐ: een H met als subscript precies 0, 1, a of A."""
    if soort != "msub" or len(rest) != 1:
        return False
    onder = unicodedata.normalize("NFKC", "".join(rest[0].itertext())).strip()
    return (unicodedata.normalize("NFKC", (basis.text or "").strip()) == "H"
            and onder in H_ONDERSCHRIFT)


def symbool_van(basis: ET.Element, rest: list[ET.Element], soort: str = "") -> Symbool:
    knopen = [basis] + [m for k in rest for m in k.iter() if naam(m) == "mi"]
    return Symbool(knopen, is_symbool(basis), (basis.text or "").strip() == "Δ",
                   is_h_etiket(soort, basis, rest))


def is_ruim(breedte: str) -> bool:
    m = re.fullmatch(r"\s*([0-9.]+)\s*em\s*", breedte or "")
    return bool(m) and float(m.group(1)) >= 0.9          # \quad en breder


def stroom(el: ET.Element) -> list[tuple]:
    """De wiskunde als platte rij: ("sym", Symbool), ("getal",), ("teken", t),
    ("knip",). De volgorde van de <mi>'s blijft die van de bladzijde."""
    n = naam(el)
    if n in ("annotation", "annotation-xml"):
        return []
    if n == "semantics":
        return stroom(el[0]) if len(el) else []
    if n == "mi":
        return [("sym", symbool_van(el, []))]
    if n == "mn":
        return [("getal",)]
    if n == "mo":
        return [("teken", (el.text or "").strip())]
    if n == "mtext":
        return [("teken", "")]
    if n == "mspace":
        return [("knip",)] if is_ruim(el.get("width", "")) else []
    if n in SCRIPTS and len(el):
        kinderen = list(el)
        basis = enkel_mi(kinderen[0])
        if basis is not None:
            return [("sym", symbool_van(basis, kinderen[1:], n))]
        uit = stroom(kinderen[0])
        for k in kinderen[1:]:
            uit += stroom(k)
        return uit
    if n == "mtable":
        uit = []
        for rij in el:
            uit += stroom(rij) + [("knip",)]
        return uit
    uit = []
    for k in el:
        uit += stroom(k)
    return uit


def etiket(deel: list[tuple]) -> list[Symbool]:
    """De symbolen van een stukje dat alleen iets aanduidt en niet rekent, of [].

    Twee vormen, allebei uit de APA-zin: `symbool = getal` (de N in
    χ²(4, N = 440)) en de vrijheidsgraden `df` (χ²(df) = …, t_{α/2}(df)). Breder
    is dit met opzet niet: in α_i(θ_s − β_i) is wat tussen de haakjes staat wél
    algebra, en daar moet de α cursief blijven.
    """
    if (len(deel) >= 3 and deel[0][0] == "sym" and deel[1][0] == "teken"
            and deel[1][1] in WAARDE
            and all(a[0] in ("getal", "teken") for a in deel[2:])
            and any(a[0] == "getal" for a in deel[2:])):
        return [deel[0][1]]
    if deel and all(a[0] == "sym" for a in deel):
        letters = "".join((a[1].knopen[0].text or "").strip() for a in deel)
        if unicodedata.normalize("NFKC", letters) == "df":
            return [a[1] for a in deel]
    return []


class Stuk:
    """Eén stuk wiskunde tussen twee knippen (stap 2)."""
    __slots__ = ("symbolen", "p_vergeleken", "hypothese")

    def __init__(self, hypothese: bool = False) -> None:
        self.symbolen: list[Symbool] = []
        self.p_vergeleken = False     # een p direct naast een teken uit VERGELIJK
        self.hypothese = hypothese    # wat na H₀: komt (zie de kop)


def alleen_etiket(stuk: Stuk) -> bool:
    return len(stuk.symbolen) == 1 and stuk.symbolen[0].h_etiket


def stukken(rij: list[tuple], hypothese: bool = False) -> list[Stuk]:
    """Knip de rij in stukken (stap 2).

    Buiten haakjes knipt een komma, puntkomma of dubbele punt. Tussen haakjes
    niet: in N(μ, σ) rekenen μ en σ samen, en een knip daar zou de μ cursief en
    de σ rechtop zetten. Wél telt een stukje dat alleen iets aanduidt niet mee
    als ánder symbool (zie etiket): de N in χ²(4, N = 440).

    Staat er vóór een dubbele punt alleen H₀, H₁ of Hₐ, dan is het stuk erna een
    hypothese. Met `hypothese=True` is de hele rij dat (een <math> die als
    geheel een hypothese is, zie hypothese_plekken).
    """
    uit: list[Stuk] = [Stuk(hypothese)]
    diepte = 0
    deel: list[tuple] = []            # het lopende stukje tussen haakjes en komma's

    def sluit_deel() -> None:
        for s in etiket(deel):
            s.telt = False
        deel.clear()

    for i, a in enumerate(rij):
        soort, teken = a[0], (a[1] if a[0] == "teken" else None)
        if soort == "knip" or teken in PIJLEN:
            sluit_deel()
            uit.append(Stuk(hypothese))
            diepte = 0
            continue
        if teken in OPEN:
            sluit_deel()
            diepte += 1
            continue
        if teken in DICHT:
            sluit_deel()
            diepte = max(diepte - 1, 0)
            continue
        if teken in KNIPTEKENS:
            voor = rij[i - 1][0] if i > 0 else None
            na = rij[i + 1][0] if i + 1 < len(rij) else None
            if teken == "," and voor == "getal" and na == "getal":
                deel.append(a)        # decimaalkomma: knipt niet
                continue
            sluit_deel()
            if diepte == 0:
                na_etiket = teken == ":" and alleen_etiket(uit[-1])
                uit.append(Stuk(hypothese or na_etiket))
            continue
        if teken in VERGELIJK:
            buren = [rij[j] for j in (i - 1, i + 1) if 0 <= j < len(rij)]
            if any(b[0] == "sym" and b[1].letter() == "p" for b in buren):
                uit[-1].p_vergeleken = True
        if soort == "sym":
            s = a[1]
            na = rij[i + 1] if i + 1 < len(rij) else None
            if s.delta and na is not None and na[0] == "sym":
                na[1].knopen[:0] = s.knopen          # Δχ²: één symbool
                continue
            uit[-1].symbolen.append(s)
        deel.append(a)
    sluit_deel()
    return uit


def is_beslisregel(stuk: Stuk) -> bool:
    """p ≤ α, p < α/2, p > α (.05): een p tegen een Griekse letter, verder
    alleen getallen en tekens (zie de kop)."""
    tellen = [s for s in stuk.symbolen if s.telt]
    grieks = [s for s in tellen if is_griekse_letter(s.letter())]
    p = [s for s in tellen if s.letter() == "p"]
    return stuk.p_vergeleken and bool(grieks) and len(grieks) + len(p) == len(tellen)


def beslis_met_reden(stuk: str, hypothese: bool = False
                     ) -> tuple[list[bool | None], list[str | None], ET.Element]:
    """Als beslis, plus per <mi> waarom hij rechtop gaat terwijl hij naast een
    ánder symbool staat: "beslisregel", "hypothese", of None."""
    boom = lees_math(stuk)
    alle = [m for m in boom.iter() if naam(m) == "mi"]
    oordeel: dict[int, bool] = {}
    reden: dict[int, str] = {}
    for st in stukken(stroom(boom), hypothese):
        benoemt = "hypothese" if st.hypothese else "beslisregel" if is_beslisregel(st) else None
        for s in st.symbolen:
            rekent = any(t.telt for t in st.symbolen if t is not s)
            for m in s.knopen:
                oordeel[id(m)] = not rekent
                if rekent and benoemt:
                    oordeel[id(m)] = True
                    reden[id(m)] = benoemt
    uit: list[bool | None] = []
    waarom: list[str | None] = []
    for m in alle:
        t = m.text or ""
        if not is_griekse_letter(t) or m.get("mathvariant") is not None:
            uit.append(None)
        elif not is_kleine_griek(t):
            uit.append(True)                       # hoofdletter: altijd rechtop
        elif id(m) not in oordeel:
            raise Onleesbaar(f"de letter {t} hoort bij geen enkel symbool")
        else:
            uit.append(oordeel[id(m)])
            waarom.append(reden.get(id(m)))
            continue
        waarom.append(None)
    return uit, waarom, boom


def beslis(stuk: str, hypothese: bool = False) -> tuple[list[bool | None], ET.Element]:
    """Per <mi> in volgorde van de bladzijde: True = rechtop zetten, False =
    cursief laten, None = niet aanraken (geen kale Griekse letter).

    Eén <math> op zichzelf. Of hij als geheel een hypothese is, ziet hij niet:
    dat hangt af van wat ervóór op de bladzijde staat (zie oordelen)."""
    uit, _, boom = beslis_met_reden(stuk, hypothese)
    return uit, boom


# ---------------------------------------------------------------- de context

def is_alleen_etiket(stuk: str) -> bool:
    """Is deze <math> niets dan H₀, H₁ of Hₐ?"""
    rij = stroom(lees_math(stuk))
    return len(rij) == 1 and rij[0][0] == "sym" and rij[0][1].h_etiket


def hypothese_plekken(bladzij: str, wiskunde: list[re.Match]) -> set[int]:
    """De beginplek van elke <math> die als geheel een hypothese is (zie de kop):
    na een <math> met alleen het etiket en daarna alleen een dubbele punt, of in
    een tabelrij waarvan de eerste cel alleen het etiket is."""
    plekken: set[int] = set()
    for vorige, deze in zip(wiskunde, wiskunde[1:]):
        tussen = bladzij[vorige.end():deze.start()]
        if ("<" not in tussen and htmlmod.unescape(tussen).strip() == ":"
                and is_alleen_etiket(vorige.group(0))):
            plekken.add(deze.start())
    for rij in TR.finditer(bladzij):
        cellen = list(CEL.finditer(rij.group(0)))
        if len(cellen) < 2:
            continue
        eerste = cellen[0].group("inhoud").strip()
        # Precies één <math> die de hele cel vult. Niet MATH.fullmatch: daar rekt
        # de .*? zich over twee <math>'s en de tekst ertussen heen.
        binnen = list(MATH.finditer(eerste))
        if not (len(binnen) == 1 and binnen[0].group(0) == eerste
                and is_alleen_etiket(eerste)):
            continue
        for cel in cellen[1:]:
            for m in MATH.finditer(cel.group("inhoud")):
                plekken.add(rij.start() + cel.start("inhoud") + m.start())
    return plekken


def oordelen(bladzij: str) -> list[tuple[re.Match, list[bool | None], list[str | None], ET.Element]]:
    """Per <math> op de bladzijde: de plek, het oordeel per <mi>, de reden, de boom."""
    wiskunde = list(MATH.finditer(bladzij))
    plekken = hypothese_plekken(bladzij, wiskunde)
    uit = []
    for mm in wiskunde:
        oordeel, waarom, boom = beslis_met_reden(mm.group(0), mm.start() in plekken)
        uit.append((mm, oordeel, waarom, boom))
    return uit


# ---------------------------------------------------------------- de bladzijde

class Telling:
    __slots__ = ("rechtop", "cursief", "vast", "formules", "benoemt", "benoemd")

    def __init__(self) -> None:
        self.rechtop = 0              # nu rechtop gezet
        self.cursief = 0              # cursief gelaten: rekent mee
        self.vast = 0                 # Griekse letter die al een mathvariant droeg
        self.formules: list[tuple[str, str]] = []     # (bron, cursieve letters)
        # Waarvan rechtop omdat ze in een beslisregel of een hypothese benoemen,
        # terwijl er een ánder symbool naast staat.
        self.benoemt = {"beslisregel": 0, "hypothese": 0}
        self.benoemd: list[tuple[str, str, str]] = []  # (reden, bron, letters)


def tex_van(boom: ET.Element) -> str:
    for el in boom.iter():
        if naam(el) == "annotation" and el.get("encoding") == "application/x-tex":
            return " ".join((el.text or "").split())
    return "(geen TeX-aantekening)"


def repareer(bladzij: str) -> tuple[str, Telling]:
    telling = Telling()

    def per_math(stuk: str, oordeel: list[bool | None], waarom: list[str | None],
                 boom: ET.Element) -> str:
        treffers = list(MI.finditer(stuk))
        if len(treffers) != len(oordeel):
            raise Onleesbaar(f"{len(treffers)} <mi> in de tekst, {len(oordeel)} in de boom")
        cursief = []
        benoemd: dict[str, list[str]] = {}
        for m, o, r in zip(treffers, oordeel, waarom):
            if o is None and is_enkel_grieks(m.group("tekst")):
                telling.vast += 1
            elif o is False:
                cursief.append(htmlmod.unescape(m.group("tekst")))
            elif o is True and r:
                telling.benoemt[r] += 1
                benoemd.setdefault(r, []).append(htmlmod.unescape(m.group("tekst")))
        telling.cursief += len(cursief)
        if cursief:
            telling.formules.append((tex_van(boom), " ".join(cursief)))
        for r, letters in benoemd.items():
            telling.benoemd.append((r, tex_van(boom), " ".join(letters)))
        volg = iter(oordeel)

        def per_mi(m: re.Match) -> str:
            if next(volg) is not True:
                return m.group(0)
            telling.rechtop += 1
            return f'<mi{m.group("attr")}{RECHTOP}>{m.group("tekst")}</mi>'

        return MI.sub(per_mi, stuk)

    delen, tot = [], 0
    for mm, oordeel, waarom, boom in oordelen(bladzij):
        delen += [bladzij[tot:mm.start()], per_math(mm.group(0), oordeel, waarom, boom)]
        tot = mm.end()
    delen.append(bladzij[tot:])
    return "".join(delen), telling


def nog_te_doen(bladzij: str) -> int:
    """Zelfcontrole, langs een andere weg dan de reparatie: hoeveel Griekse
    letters horen rechtop en dragen nog geen mathvariant? Leest de bladzijde
    zoals hij geschreven is, opnieuw, met zijn context."""
    return sum(o is True for _, oordeel, _, _ in oordelen(bladzij) for o in oordeel)


# ---------------------------------------------------------------- waar en welke

def wortel() -> Path:
    hier = Path(__file__).resolve().parent
    return hier.parent if hier.name == "_controles" else hier


def bladzijden(paden: list[str]) -> list[Path]:
    if paden:
        p = Path(paden[0])
        return [p] if p.is_file() else sorted(p.rglob("*.html"))
    uit = os.environ.get("QUARTO_PROJECT_OUTPUT_DIR")
    return sorted((wortel() / (uit or "_site")).rglob("*.html"))


def vergelijk_met_origineel() -> tuple[str, Path | None]:
    """("origineel" | "gelijk" | "anders" | "niet gevonden" | "geen bestand", pad)."""
    hier = Path(__file__)
    if not hier.is_file():
        return "geen bestand", None   # uitgevoerd uit het origineel zelf (ozp1_wacht)
    hier = hier.resolve()
    for map_ in hier.parents:
        kandidaat = map_.joinpath(*ORIGINEEL)
        if kandidaat.is_file():
            if kandidaat.resolve() == hier:
                return "origineel", kandidaat
            if kandidaat.read_bytes() == hier.read_bytes():
                return "gelijk", kandidaat
            return "anders", kandidaat
    return "niet gevonden", None


def kort(p: Path) -> str:
    try:
        return str(p.relative_to(wortel()))
    except ValueError:
        return str(p)


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    toets, toon = "--toets" in argv, "--toon" in argv
    paden = [a for a in argv if not a.startswith("-")]

    stand, origineel = vergelijk_met_origineel()
    if stand == "anders":
        print(f"grieks_rechtop: deze kopie wijkt af van het origineel.\n"
              f"    kopie:      {Path(__file__).resolve()}\n"
              f"    origineel:  {origineel}\n"
              f"  Eén tekst op drie plekken; neem het origineel over:\n"
              f"    cp '{origineel}' '{Path(__file__).resolve()}'", file=sys.stderr)
        return 1
    if stand == "gelijk":
        print("grieks_rechtop: deze kopie is byte voor byte gelijk aan het origineel")
    if stand == "niet gevonden":
        print("grieks_rechtop: het origineel staat niet boven deze map; deze kopie "
              "is niet vergeleken")

    paginas = bladzijden(paden)
    if not paginas:
        # Stilte is hier geen goed nieuws: als er niets gevonden is, is er niet
        # gekeken. Zeg dat hardop in plaats van schoon af te sluiten.
        print("grieks_rechtop: 0 bladzijden gevonden -- ER IS NIET GEKEKEN", file=sys.stderr)
        return 3

    totaal = Telling()
    veranderd = 0
    for p in paginas:
        oud = p.read_text(encoding="utf-8")
        try:
            nieuw, t = repareer(oud)
        except Onleesbaar as e:
            print(f"grieks_rechtop: {kort(p)}: {e} -- niet gekeken", file=sys.stderr)
            return 3
        totaal.rechtop += t.rechtop
        totaal.cursief += t.cursief
        totaal.vast += t.vast
        for r, n in t.benoemt.items():
            totaal.benoemt[r] += n
        if toon and t.formules:
            print(f"{kort(p)}: {t.cursief} cursief gelaten, in {len(t.formules)} formule(s)")
            for tex, letters in t.formules:
                print(f"    [{letters}]  {tex}")
        if toon and t.benoemd:
            print(f"{kort(p)}: {sum(t.benoemt.values())} rechtop in een beslisregel of "
                  f"hypothese, in {len(t.benoemd)} formule(s)")
            for r, tex, letters in t.benoemd:
                print(f"    {r}: [{letters}]  {tex}")
        if t.rechtop:
            veranderd += 1
            if not (toets or toon):
                p.write_text(nieuw, encoding="utf-8")

    woord = "zou rechtop gaan" if (toets or toon) else "rechtop gezet"
    print(f"grieks_rechtop: {len(paginas)} bladzijden; {totaal.rechtop} Griekse letter(s) "
          f"{woord} (benoemt, of krijgt een waarde), {totaal.cursief} cursief gelaten "
          f"(rekent mee in een formule), {totaal.vast} droegen al een mathvariant "
          f"(uit de bron, of uit een eerdere ronde)")
    print(f"grieks_rechtop: daarvan {totaal.benoemt['beslisregel']} in een beslisregel "
          f"(p ≤ α) en {totaal.benoemt['hypothese']} in een hypothese (H₀: μ₁ = μ₂), "
          f"waar ze naast een ánder symbool toch benoemen")

    if toets or toon:
        return 1 if (toets and totaal.rechtop) else 0

    # Zelfcontrole: staat er nog een Griekse letter cursief die rechtop hoort?
    rest = sum(nog_te_doen(p.read_text(encoding="utf-8")) for p in paginas)
    if rest:
        print(f"grieks_rechtop: {rest} Griekse letter(s) die rechtop horen, staan nog "
              f"cursief", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
