--[[
wiskunde.lua -- lucht rond een teken tussen twee woorden, in de MathML

WAT HET DOET. Staat er in een stuk wiskunde een rij met alleen tekst en één
teken, zoals

    \dfrac{\text{rijtotaal} \times \text{kolomtotaal}}{N}
    r_{\text{denkkunst}, \text{zelfgevoel}}

dan tekent Chrome dat teken zonder lucht: "rijtotaal×kolomtotaal". Dit filter
zet in zo'n rij één leeg <mi></mi> achteraan. Dat tekent niets, maar daarmee
krijgt het teken weer de lucht die het hoort te hebben.

WAAROM. MathML Core telt tekst (<mtext>) als witruimte. Een rij die bestaat uit
één teken plus alleen "witruimte" is daarmee als geheel een teken (een
"versierde operator", §3.2.4.1), en de lucht gaat dan om de hele rij heen in
plaats van rond het teken binnenin (§3.3.1.2). Gemeten in Chrome 158: 0 em
links en rechts van de ×, ook met een lspace-attribuut in de MathML. LaTeX
kent dat niet: daar is \text{...} een gewoon stuk tekst, en krijgt de × zijn
4/18 em aan beide kanten. Een leeg <mi> is geen witruimte, dus de rij is weer
een gewone rij. Het W3C bespreekt de regel nog (w3c/mathml-core#286).

WAAROM NIET IN CSS. Een marge rond het teken zou in Chrome werken, maar Safari
(WebKit) maakt alleen van een rij met één kind een operator, en zet de lucht
hier al goed. Daar zou een marge de lucht verdubbelen. Een leeg <mi> doet in
beide niets verkeerds: in Safari staat het er, en tekent het niets.

WAT HET AANRAAKT. Alleen HTML-uitvoer, alleen formules met \text erin, en
daarbinnen alleen een <mrow> waarvan de kinderen <mtext>, <mspace> en precies
één <mo> zijn, met ten minste één <mtext>. Elke andere formule laat het filter
staan zoals pandoc hem maakt (het geeft nil terug). Voor een formule die het
wél aanraakt, maakt het filter de MathML met pandoc's eigen schrijver en
dezelfde instelling (mathml), zodat de rest -- annotatie met de TeX, de
<span class="math ..."> eromheen -- gelijk blijft.

WAT HET NIET ZIET. Een rij met een geneste groep van alleen witruimte erin
(\text{ en } maakt <mrow><mspace/><mtext> en </mtext><mspace/></mrow>): die
rij is niet "binnenste", en blijft zoals hij was. Toen dit filter erin kwam,
stond zo'n rij in TS, OZP 2 en MVDA nergens.

ÉÉN TEKST OP DRIE PLEKKEN. Het origineel staat in OZP 1
(_common/filters/wiskunde.lua); TS en OZP 2 lezen dat via hun _common. MVDA en
Psychometrie hebben een kopie, bijgehouden door _tools/wiskunde_uitrollen.py.
]]

if not FORMAT:match("html") then
  return {}
end

-- Is de inhoud van een binnenste <mrow> precies: mtext/mspace en één mo?
local function is_tekstrij(inhoud)
  local i, n_mo, n_tekst = 1, 0, 0
  while i <= #inhoud do
    local s, e, tag = inhoud:find("^<(%a+)[^>]*/>", i)
    if not s then
      s, e, tag = inhoud:find("^<(%a+)[^>]*>.-</%1>", i)
    end
    if not s then
      return false
    end
    if tag == "mo" then
      n_mo = n_mo + 1
    elseif tag == "mtext" then
      n_tekst = n_tekst + 1
    elseif tag ~= "mspace" then
      return false
    end
    i = e + 1
  end
  return n_mo == 1 and n_tekst >= 1
end

-- Zet <mi></mi> achteraan in elke binnenste tekstrij. Geeft (html, aantal).
local function repareer(html)
  local delen, i, n = {}, 1, 0
  while true do
    local s, e = html:find("<mrow>", i, true)
    if not s then break end
    local sluit = html:find("</mrow>", e + 1, true)
    if not sluit then break end
    local inhoud = html:sub(e + 1, sluit - 1)
    if not inhoud:find("<mrow", 1, true) and is_tekstrij(inhoud) then
      delen[#delen + 1] = html:sub(i, sluit - 1) .. "<mi></mi>"
      i = sluit
      n = n + 1
    else
      delen[#delen + 1] = html:sub(i, e)
      i = e + 1
    end
  end
  delen[#delen + 1] = html:sub(i)
  return table.concat(delen), n
end

return {
  {
    Math = function(el)
      if not el.text:find("\\text", 1, true) then
        return nil
      end
      local doc = pandoc.Pandoc({ pandoc.Plain({ el }) })
      local html = pandoc.write(doc, "html", { html_math_method = "mathml" })
      html = html:gsub("%s+$", "")
      local nieuw, n = repareer(html)
      if n == 0 then
        return nil
      end
      return pandoc.RawInline("html", nieuw)
    end,
  },
}
