#' CountCamp techniek-diagram — sets met pijlen ertussen
#'
#' Tekent een ggplot-diagram met rechthoeken (sets variabelen) en pijlen
#' (technieken / relaties). Voor consistent overzicht per MVDA-thema:
#' MRA / ANOVA / ANCOVA / LRA / MANOVA / DDA / RMA / Mediation.
#'
#' Gebaseerd op een handgetekende stijl met sets en pijlen:
#' meetniveau bovenin het blok, set-naam in vet, variabele-namen daaronder,
#' aantal als footnote. Pijl met techniek-label tussen blokken.
#'
#' @param blocks Lijst met per blok een named list met velden:
#'   - id: unieke string-identifier (gebruikt voor arrow-from/to)
#'   - label: hoofdtekst (bv. "sociale_status")
#'   - vars: variabel-namen of toelichting (bv. "alpha / mid / outsider")
#'   - level: "nominaal" / "ordinaal" / "interval" / "afgeleid interval"
#'   - note: footer-tekst (bv. "3 groepen")
#'   - x, y: positie midden van het blok
#'   - width, height: optioneel, standaard 3.0 en 1.7
#'   Optioneel:
#'   - onder: tekst ónder het blok, bv. "nom · 1 variabele". Staat hij er,
#'     dan vervalt het meetniveau bovenin het blok: het staat dan onder.
#'   - rijen: de variabelen als losse regels onder elkaar, in plaats van
#'     `vars` op één regel. Een pijl kan dan bij één rij beginnen of eindigen
#'     (zie `van_rij` en `naar_rij` hieronder).
#'   - rijen_parse: TRUE als de rijen plotmath zijn, bv. "italic(D)[1]".
#' @param arrows data.frame met kolommen `from`, `to`, `label`. Optioneel:
#'   - van_rij, naar_rij: rijnummer binnen het blok (NA = midden van het blok)
#'   - parse: TRUE als het label plotmath is, bv. "italic(b)[1*','*1]"
#'   - label_pos: waar op de pijl het label staat, 0 = begin, 1 = eind
#'     (standaard 0.5)
#'   Een pijl mag naar links wijzen: ligt `to` links van `from`, dan loopt
#'   hij van de linkerrand van `from` naar de rechterrand van `to`.
#' @param title Optioneel: titel boven het diagram
#'
#' @return Een ggplot-object
cc_techniek_diagram <- function(blocks, arrows, title = NULL) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 is nodig voor cc_techniek_diagram()")
  }

  # Tol-Vibrant-achtige pastel-kleuren per meetniveau
  level_colors <- c(
    "nominaal"          = "#FFE0B3",
    "ordinaal"          = "#FFF2B3",
    "interval"          = "#CCE5FF",
    "afgeleid interval" = "#E5CCFF"
  )

  # Blocks omzetten naar data.frame
  bf <- do.call(rbind, lapply(blocks, function(b) {
    data.frame(
      id     = b$id,
      label  = b$label,
      vars   = if (is.null(b$vars) || !is.null(b$rijen)) "" else b$vars,
      level  = b$level,
      note   = if (is.null(b$note)) "" else b$note,
      onder  = if (is.null(b$onder)) "" else b$onder,
      x      = b$x,
      y      = b$y,
      width  = if (is.null(b$width)) 3.0 else b$width,
      height = if (is.null(b$height)) 1.7 else b$height,
      rijen  = !is.null(b$rijen),
      stringsAsFactors = FALSE
    )
  }))

  bf$xmin <- bf$x - bf$width / 2
  bf$xmax <- bf$x + bf$width / 2
  bf$ymin <- bf$y - bf$height / 2
  bf$ymax <- bf$y + bf$height / 2
  bf$fill <- unname(level_colors[bf$level])
  # Met een tekst onder het blok staat het meetniveau daar, niet bovenin.
  bf$level_boven <- ifelse(bf$onder == "", bf$level, "")
  # Met rijen staat de set-naam bovenin het blok; zonder rijen net boven het
  # midden, zoals altijd.
  bf$label_y <- ifelse(bf$rijen, bf$ymax - 0.30, bf$y + bf$height * 0.10)

  # Rijen: per blok de variabelen onder elkaar, onder de set-naam.
  rf <- do.call(rbind, lapply(blocks, function(b) {
    if (is.null(b$rijen)) return(NULL)
    r  <- bf[bf$id == b$id, ]
    n  <- length(b$rijen)
    yy <- if (n == 1) r$y - 0.15 else seq(r$ymax - 0.75, r$ymin + 0.30, length.out = n)
    data.frame(id = b$id, rij = seq_len(n), tekst = b$rijen, x = r$x, y = yy,
               parse = isTRUE(b$rijen_parse), stringsAsFactors = FALSE)
  }))
  rij_y <- function(id, rij) {
    if (is.na(rij)) return(bf$y[match(id, bf$id)])
    rf$y[rf$id == id & rf$rij == rij]
  }

  # Pijlen — koppel via match(). Ligt het doel links van het begin, dan loopt
  # de pijl van de linkerrand naar de rechterrand.
  af <- arrows
  if (is.null(af$van_rij))   af$van_rij   <- NA_integer_
  if (is.null(af$naar_rij))  af$naar_rij  <- NA_integer_
  if (is.null(af$parse))     af$parse     <- FALSE
  if (is.null(af$label_pos)) af$label_pos <- 0.5
  van  <- match(af$from, bf$id)
  naar <- match(af$to,   bf$id)
  links <- bf$x[naar] < bf$x[van]
  af$x_start <- ifelse(links, bf$xmin[van],  bf$xmax[van])
  af$x_end   <- ifelse(links, bf$xmax[naar], bf$xmin[naar])
  af$y_start <- mapply(rij_y, af$from, af$van_rij)
  af$y_end   <- mapply(rij_y, af$to,   af$naar_rij)
  af$x_mid   <- af$x_start + af$label_pos * (af$x_end - af$x_start)
  af$y_mid   <- af$y_start + af$label_pos * (af$y_end - af$y_start)
  # Een pijl die bij een rij begint, is dun: er lopen er dan meer naast elkaar.
  af$dik     <- ifelse(is.na(af$van_rij) & is.na(af$naar_rij), 1, 0.5)
  af$dy      <- ifelse(af$dik == 1, 0.28, 0.12)

  p <- ggplot2::ggplot() +
    # Blokken (rechthoeken)
    ggplot2::geom_rect(
      data = bf,
      ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
      color = "black", linewidth = 0.6
    ) +
    # Meetniveau-label (bovenin, italic)
    ggplot2::geom_text(
      data = bf,
      ggplot2::aes(x = x, y = y + height * 0.34, label = level_boven),
      size = 3.4, fontface = "italic", color = "gray30"
    ) +
    # Hoofdtekst (vet)
    ggplot2::geom_text(
      data = bf,
      ggplot2::aes(x = x, y = label_y, label = label),
      size = 4.2, fontface = "bold"
    ) +
    # Variabele-namen
    ggplot2::geom_text(
      data = bf,
      ggplot2::aes(x = x, y = y - height * 0.13, label = vars),
      size = 3.4
    ) +
    # Footnote
    ggplot2::geom_text(
      data = bf,
      ggplot2::aes(x = x, y = y - height * 0.36, label = note),
      size = 3.0, fontface = "italic", color = "gray40"
    ) +
    # Onder het blok: meetniveau en aantal variabelen
    ggplot2::geom_text(
      data = bf,
      ggplot2::aes(x = x, y = ymin - 0.32, label = onder),
      size = 3.6, color = "gray20"
    )

  if (!is.null(rf)) {
    for (pm in unique(rf$parse)) {
      p <- p + ggplot2::geom_text(
        data = rf[rf$parse == pm, ], ggplot2::aes(x = x, y = y, label = tekst),
        size = if (pm) 4.6 else 3.4, parse = pm
      )
    }
  }

  # Pijlen. Een set-naar-set-pijl is dik met een grote punt; een rij-pijl is
  # dun met een kleinere punt, want er lopen er dan meer naast elkaar.
  for (dun in c(FALSE, TRUE)) {
    d <- af[(af$dik < 1) == dun, , drop = FALSE]
    if (nrow(d) == 0) next
    p <- p + ggplot2::geom_segment(
      data = d,
      ggplot2::aes(x = x_start, xend = x_end, y = y_start, yend = y_end),
      arrow = ggplot2::arrow(length = ggplot2::unit(if (dun) 0.22 else 0.4, "cm"),
                             type = "closed"),
      linewidth = if (dun) 0.5 else 1
    )
  }

  # Pijl-labels: gewone tekst en plotmath apart, want parse geldt per laag.
  for (pm in c(FALSE, TRUE)) {
    d <- af[af$parse == pm & af$label != "", , drop = FALSE]
    if (nrow(d) == 0) next
    p <- p + ggplot2::geom_label(
      data = d,
      ggplot2::aes(x = x_mid, y = y_mid + dy, label = label),
      size = ifelse(pm, 3.4, 3.6), fontface = if (pm) "plain" else "bold",
      # linewidth = 0: geen rand. Heette tot ggplot2 3.5.0 `label.size`; die
      # naam geeft sindsdien een waarschuwing.
      fill = "white", linewidth = 0, parse = pm,
      label.padding = ggplot2::unit(if (pm) 0.08 else 0.18, "lines")
    )
  }

  p +
    ggplot2::scale_fill_identity() +
    ggplot2::coord_fixed(clip = "off") +
    ggplot2::theme_void() +
    ggplot2::theme(
      plot.margin = ggplot2::margin(15, 15, 15, 15),
      plot.title = ggplot2::element_text(hjust = 0.5, size = 13, face = "bold")
    ) +
    {if (!is.null(title)) ggplot2::ggtitle(title) else NULL}
}
