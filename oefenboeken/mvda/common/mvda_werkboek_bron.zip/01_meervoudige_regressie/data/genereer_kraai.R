# Genereer kraai_observatorium dataset voor het MRA-thema, R-practical voorbeeld.
# Dier-context: een observatorium meet bij 73 kraaien hoe oplettend ze zijn,
# en wat hun nestgrootte (cm), weersgehoor (schaal 0-100) en paargedrag
# (schaal 0-100) bijdragen aan oplettendheid (schaal 0-100).
#
# Met set.seed(20260504) reproduceerbaar.

set.seed(20260504)

N <- 73

# Latente voorspellers, deels gecorreleerd (mild — geen multicollineariteit-probleem)
nestgrootte  <- round(rnorm(N, mean = 28, sd = 5), 1)            # cm
weersgehoor  <- round(50 + 0.6 * (nestgrootte - 28) + rnorm(N, 0, 11), 1)
paargedrag   <- round(rnorm(N, mean = 55, sd = 12), 1)

# Outcome: oplettendheid hangt samen met alle drie voorspellers — nestgrootte
# zwakker, weersgehoor en paargedrag sterker.
oplettendheid <- 10 +
                 0.45 * nestgrootte +
                 0.55 * weersgehoor +
                 0.32 * paargedrag +
                 rnorm(N, 0, 7)
oplettendheid <- round(pmin(pmax(oplettendheid, 0), 100), 1)

kraai_data <- data.frame(
  oplettendheid = oplettendheid,
  nestgrootte   = nestgrootte,
  weersgehoor   = weersgehoor,
  paargedrag    = paargedrag
)

# Controle: gewenste structuur en samenhangen
str(kraai_data)
round(cor(kraai_data), 3)
summary(lm(oplettendheid ~ nestgrootte + weersgehoor + paargedrag,
           data = kraai_data))

save(kraai_data, file = "data/kraai_observatorium.RData")
