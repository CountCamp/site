# Genereer kerkuil_nacht dataset voor het LRA-thema, R-practical E5.
#
# Dier-context: een kerkuil observeert nachtelijk gedrag van dieren
# in zijn revier. Wie sliep onrustig? Hij vermoedt dat zorgen,
# laat-eten en sociale isolatie meespelen.
#
# Eén binair Y (sliep_onrustig), twee continue voorspellers, één factor:
#   - aantal_zorgen     (continu count, hoeveel zorgen het dier
#                        de afgelopen week had)
#   - eet_voor_slapen   (continu, hapjes-frequentie 's avonds, schaal 0-5)
#   - sociale_isolatie  (factor: nee / ja / twijfelend)
#
# Doelen:
#   - aantal_zorgen:    sterk significant, OR > 1.
#   - eet_voor_slapen:  significant, OR > 1.
#   - sociale_isolatie: factor LR-toets significant
#                       (geïsoleerden slapen onrustiger).
#   - pseudo-R^2 ~ .25-.35
#   - N = 118 (tussen 100 en 130)
#   - accuracy ~ 70-78%
#
# Reproduceerbaar via set.seed(20260508).

set.seed(20260508)

N <- 118

aantal_zorgen   <- pmin(rpois(N, lambda = 2.5), 12)
eet_voor_slapen <- round(runif(N, 0, 5), 1)

sociale_isolatie <- factor(
  sample(c("ja", "nee", "twijfelend"), size = N, replace = TRUE,
         prob = c(0.30, 0.45, 0.25)),
  levels = c("nee", "ja", "twijfelend")
)

# Lineaire predictor.
b0    <- -2.50
b_zor <-  0.55    # meer zorgen => meer onrustig
b_eet <-  0.30    # meer hapjes voor slapen => meer onrustig
b_iso <- c(nee = 0, ja = 0.80, twijfelend = 0.40)

eta <- b0 +
       b_zor * aantal_zorgen   +
       b_eet * eet_voor_slapen +
       b_iso[as.character(sociale_isolatie)]

p_onrustig <- plogis(eta)

set.seed(11)
sliep_onrustig <- rbinom(N, size = 1, prob = p_onrustig)

kerkuil_nacht <- data.frame(
  sliep_onrustig    = as.integer(sliep_onrustig),
  aantal_zorgen     = as.integer(aantal_zorgen),
  eet_voor_slapen   = as.numeric(eet_voor_slapen),
  sociale_isolatie  = sociale_isolatie
)

cat("--- structuur ---\n"); str(kerkuil_nacht)
cat("--- frequenties sliep_onrustig ---\n"); print(table(kerkuil_nacht$sliep_onrustig))
cat("--- frequenties sociale_isolatie ---\n"); print(table(kerkuil_nacht$sociale_isolatie))

m <- glm(sliep_onrustig ~ aantal_zorgen + eet_voor_slapen + sociale_isolatie,
         data = kerkuil_nacht, family = binomial(link = "logit"))
cat("--- summary ---\n"); print(summary(m))
cat("--- OR's ---\n"); print(round(exp(coef(m)), 3))
cat("--- 95%-CI OR ---\n"); print(round(exp(confint.default(m)), 3))

m0 <- glm(sliep_onrustig ~ 1, data = kerkuil_nacht, family = binomial)
cat("--- LR volledig vs null ---\n"); print(anova(m0, m, test = "Chisq"))

LL0 <- as.numeric(logLik(m0))
LLk <- as.numeric(logLik(m))
cat("--- pseudo-R^2 ---\n"); print(round(1 - LLk / LL0, 3))

phat <- predict(m, type = "response")
yhat <- ifelse(phat >= 0.5, 1, 0)
ctab <- table(observed = kerkuil_nacht$sliep_onrustig, predicted = yhat)
cat("--- classificatie-tabel ---\n"); print(ctab)
cat("--- accuracy ---\n"); print(round(sum(diag(ctab)) / sum(ctab), 3))

suppressPackageStartupMessages(library(car))
cat("--- car::Anova LR per term ---\n")
print(car::Anova(m, type = "II", test.statistic = "LR"))

save(kerkuil_nacht, file = "data/kerkuil_nacht.RData")
