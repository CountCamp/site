# Genereer pad_spiegel dataset voor het LRA-thema (4.1, 4.2).
#
# Dier-context: een pad zit aan zijn vijver en kijkt wat dieren doen
# als ze langs het water komen. Sommige bekijken zichzelf even in
# het water, andere niet. Pad noteert.
#
# Twee continue voorspellers (leeftijd, aantal_afwijzingen) en één
# factor (diersoort, 3 niveaus). Y is binair (bekeek_zichzelf, 0/1).
#
# Doelen voor de kalibratie:
#   - leeftijd:           significant, OR < 1 (jonger => meer spiegel-gedrag).
#                         b ~ -0.15, OR ~ 0.86 per jaar.
#   - aantal_afwijzingen: significant, OR > 1 (afgewezen => meer zelfreflectie).
#                         b ~ 0.29, OR ~ 1.34 per afwijzing.
#   - diersoort:          factor LR-toets significant.
#                         vos hoogst, das laagst, ree wisselend (referentie).
#   - pseudo-R^2 (Hosmer-Lemeshow / McFadden): .20-.30
#   - geen extreme multicollineariteit (VIF < 2)
#   - classificatie-accuratesse 70-78%
#   - N = 152
#
# Reproduceerbaar via set.seed(20260507).

set.seed(20260507)

N <- 152

# Leeftijd in jaren (1-12, vrij uniform — gemengde populatie van jong tot oud).
leeftijd <- round(runif(N, min = 1, max = 12), 1)

# Aantal afwijzingen in de afgelopen weken (count, scheef, gewogen tot 0-10).
aantal_afwijzingen <- pmin(rpois(N, lambda = 2.7), 10)

# Diersoort: factor 3 niveaus.
diersoort <- factor(
  sample(c("ree", "vos", "das"), size = N, replace = TRUE,
         prob = c(0.40, 0.35, 0.25)),
  levels = c("ree", "vos", "das")
)

# Lineaire predictor (log-odds) van zichzelf bekijken.
#  - intercept zo gekozen dat baseline-kans rond 0.50 ligt
#  - leeftijd b = -0.13 per jaar (jonger = vaker)
#  - aantal_afwijzingen b = 0.30 per afwijzing (meer afwijzing = meer zelfreflectie)
#  - diersoort: ree = 0 (referentie), vos = +1.5, das = -1.5
b0      <-  0.00
b_leef  <- -0.13
b_afw   <-  0.30
b_dier  <- c(ree = 0, vos = 1.5, das = -1.5)

eta <- b0 +
       b_leef * leeftijd +
       b_afw  * aantal_afwijzingen +
       b_dier[as.character(diersoort)]

# Logit-link: p = 1 / (1 + exp(-eta))
p_kijk <- plogis(eta)

set.seed(9000)   # kleine seed-jump voor de Bernoulli-trekking
bekeek_zichzelf <- rbinom(N, size = 1, prob = p_kijk)

pad_spiegel <- data.frame(
  bekeek_zichzelf    = as.integer(bekeek_zichzelf),
  leeftijd           = as.numeric(leeftijd),
  aantal_afwijzingen = as.integer(aantal_afwijzingen),
  diersoort          = diersoort
)

# Snelle controles
cat("--- structuur ---\n"); str(pad_spiegel)
cat("--- frequenties bekeek_zichzelf ---\n"); print(table(pad_spiegel$bekeek_zichzelf))
cat("--- proportie bekijkers ---\n"); print(round(prop.table(table(pad_spiegel$bekeek_zichzelf)), 3))
cat("--- frequenties diersoort ---\n"); print(table(pad_spiegel$diersoort))

# Volledig model
m_full <- glm(bekeek_zichzelf ~ leeftijd + aantal_afwijzingen + diersoort,
              data = pad_spiegel, family = binomial(link = "logit"))
cat("--- summary volledig model ---\n"); print(summary(m_full))
cat("--- odds ratios ---\n"); print(round(exp(coef(m_full)), 3))
cat("--- 95%-CI op OR-schaal ---\n")
print(round(exp(confint.default(m_full)), 3))

# Null-model en LR-toets
m_null <- glm(bekeek_zichzelf ~ 1, data = pad_spiegel,
              family = binomial(link = "logit"))
cat("--- LR-toets volledig vs null ---\n")
print(anova(m_null, m_full, test = "Chisq"))

# Pseudo-R^2 (McFadden / Hosmer-Lemeshow)
LL0 <- as.numeric(logLik(m_null))
LLk <- as.numeric(logLik(m_full))
pseudoR2 <- 1 - (LLk / LL0)
cat("--- pseudo-R^2 (McFadden) ---\n"); print(round(pseudoR2, 3))

# Classificatie-tabel met cutoff 0.5
phat <- predict(m_full, type = "response")
yhat <- ifelse(phat >= 0.5, 1, 0)
ctab <- table(observed = pad_spiegel$bekeek_zichzelf, predicted = yhat)
cat("--- classificatie-tabel (cutoff .5) ---\n"); print(ctab)
acc  <- sum(diag(ctab)) / sum(ctab)
sens <- ctab["1", "1"] / sum(ctab["1", ])
spec <- ctab["0", "0"] / sum(ctab["0", ])
cat("--- accuracy / sensitivity / specificity ---\n")
print(round(c(accuracy = acc, sensitivity = sens, specificity = spec), 3))

# VIF
suppressPackageStartupMessages(library(car))
cat("--- VIF (GVIF voor factor) ---\n"); print(vif(m_full))

# LR-toets per term
cat("--- car::Anova LR per term ---\n")
print(car::Anova(m_full, type = "II", test.statistic = "LR"))

save(pad_spiegel, file = "data/pad_spiegel.RData")
